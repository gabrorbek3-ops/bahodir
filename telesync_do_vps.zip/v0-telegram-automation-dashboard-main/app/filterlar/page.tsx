"use client"

import { useState } from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import {
  Plus,
  MoreVertical,
  Trash2,
  Edit,
  Filter,
  Replace,
  CreditCard,
  Phone,
  AtSign,
  Link,
  Eye,
  EyeOff,
  Code,
  CheckCircle,
  XCircle,
} from "lucide-react"

interface FilterRule {
  id: number
  name: string
  type: "card" | "phone" | "username" | "link" | "custom"
  pattern: string
  replacement: string
  enabled: boolean
  matchCount: number
}

interface ReplaceRule {
  id: number
  name: string
  findText: string
  replaceText: string
  isRegex: boolean
  caseSensitive: boolean
  enabled: boolean
  matchCount: number
}

const initialFilters: FilterRule[] = [
  {
    id: 1,
    name: "Karta raqamlari",
    type: "card",
    pattern: "\\d{4}[\\s-]?\\d{4}[\\s-]?\\d{4}[\\s-]?\\d{4}",
    replacement: "****-****-****-****",
    enabled: true,
    matchCount: 1234,
  },
  {
    id: 2,
    name: "Telefon raqamlari",
    type: "phone",
    pattern: "\\+?\\d{12}|\\d{2}[\\s-]?\\d{3}[\\s-]?\\d{2}[\\s-]?\\d{2}",
    replacement: "+998*********",
    enabled: true,
    matchCount: 856,
  },
  {
    id: 3,
    name: "Telegram username",
    type: "username",
    pattern: "@[a-zA-Z0-9_]{5,32}",
    replacement: "@hidden_user",
    enabled: false,
    matchCount: 2341,
  },
  {
    id: 4,
    name: "Tashqi havolalar",
    type: "link",
    pattern: "https?://[^\\s]+",
    replacement: "[havola olib tashlandi]",
    enabled: true,
    matchCount: 567,
  },
]

const initialReplaces: ReplaceRule[] = [
  {
    id: 1,
    name: "Kanal nomini almashtirish",
    findText: "@old_channel",
    replaceText: "@new_channel",
    isRegex: false,
    caseSensitive: true,
    enabled: true,
    matchCount: 456,
  },
  {
    id: 2,
    name: "Reklama matnlarini olib tashlash",
    findText: "(?i)reklama|ad|sponsor",
    replaceText: "",
    isRegex: true,
    caseSensitive: false,
    enabled: true,
    matchCount: 123,
  },
  {
    id: 3,
    name: "Eski admin nomini yangilash",
    findText: "Admin: @old_admin",
    replaceText: "Admin: @new_admin",
    isRegex: false,
    caseSensitive: true,
    enabled: false,
    matchCount: 89,
  },
]

const filterTypeConfig = {
  card: { label: "Karta", icon: CreditCard, color: "text-warning" },
  phone: { label: "Telefon", icon: Phone, color: "text-success" },
  username: { label: "Username", icon: AtSign, color: "text-primary" },
  link: { label: "Havola", icon: Link, color: "text-accent" },
  custom: { label: "Maxsus", icon: Code, color: "text-muted-foreground" },
}

export default function FiltersPage() {
  const [filters, setFilters] = useState<FilterRule[]>(initialFilters)
  const [replaces, setReplaces] = useState<ReplaceRule[]>(initialReplaces)
  const [isAddFilterOpen, setIsAddFilterOpen] = useState(false)
  const [isAddReplaceOpen, setIsAddReplaceOpen] = useState(false)
  const [newFilter, setNewFilter] = useState({
    name: "",
    type: "custom" as FilterRule["type"],
    pattern: "",
    replacement: "",
  })
  const [newReplace, setNewReplace] = useState({
    name: "",
    findText: "",
    replaceText: "",
    isRegex: false,
    caseSensitive: true,
  })

  const handleAddFilter = () => {
    const newId = Math.max(...filters.map((f) => f.id), 0) + 1
    setFilters([
      ...filters,
      {
        id: newId,
        ...newFilter,
        enabled: true,
        matchCount: 0,
      },
    ])
    setIsAddFilterOpen(false)
    setNewFilter({ name: "", type: "custom", pattern: "", replacement: "" })
  }

  const handleAddReplace = () => {
    const newId = Math.max(...replaces.map((r) => r.id), 0) + 1
    setReplaces([
      ...replaces,
      {
        id: newId,
        ...newReplace,
        enabled: true,
        matchCount: 0,
      },
    ])
    setIsAddReplaceOpen(false)
    setNewReplace({
      name: "",
      findText: "",
      replaceText: "",
      isRegex: false,
      caseSensitive: true,
    })
  }

  const toggleFilter = (id: number) => {
    setFilters(
      filters.map((f) => (f.id === id ? { ...f, enabled: !f.enabled } : f))
    )
  }

  const toggleReplace = (id: number) => {
    setReplaces(
      replaces.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r))
    )
  }

  const deleteFilter = (id: number) => {
    setFilters(filters.filter((f) => f.id !== id))
  }

  const deleteReplace = (id: number) => {
    setReplaces(replaces.filter((r) => r.id !== id))
  }

  const enabledFiltersCount = filters.filter((f) => f.enabled).length
  const enabledReplacesCount = replaces.filter((r) => r.enabled).length

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="pl-64 transition-all duration-300">
        {/* Header */}
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-background/95 px-6 backdrop-blur">
          <h1 className="text-xl font-semibold text-foreground">
            Filterlar va almashtirish qoidalari
          </h1>
        </header>

        <div className="p-6 space-y-6">
          {/* Stats */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Filter className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">
                      {filters.length}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Jami filterlar
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                    <CheckCircle className="h-5 w-5 text-success" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">
                      {enabledFiltersCount}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Faol filterlar
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                    <Replace className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">
                      {replaces.length}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Almashtirish qoidalari
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/10">
                    <Eye className="h-5 w-5 text-warning" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">
                      {filters
                        .reduce((acc, f) => acc + f.matchCount, 0)
                        .toLocaleString()}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Jami topilgan
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="filters" className="space-y-4">
            <TabsList className="bg-muted">
              <TabsTrigger value="filters">
                Maxfiy ma'lumot filterlari
              </TabsTrigger>
              <TabsTrigger value="replace">Matn almashtirish</TabsTrigger>
            </TabsList>

            {/* Filters Tab */}
            <TabsContent value="filters" className="space-y-4">
              <Card className="bg-card border-border">
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle className="text-foreground">
                      Maxfiy ma'lumotlarni yashirish
                    </CardTitle>
                    <CardDescription>
                      Karta raqamlari, telefon raqamlari va boshqa maxfiy
                      ma'lumotlarni avtomatik yashirish
                    </CardDescription>
                  </div>
                  <Dialog
                    open={isAddFilterOpen}
                    onOpenChange={setIsAddFilterOpen}
                  >
                    <DialogTrigger asChild>
                      <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                        <Plus className="mr-2 h-4 w-4" />
                        Yangi filter
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>Yangi filter qo'shish</DialogTitle>
                        <DialogDescription>
                          Maxfiy ma'lumotlarni yashirish uchun qoida yarating.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                          <Label>Filter nomi</Label>
                          <Input
                            placeholder="Masalan: Karta raqamlari"
                            value={newFilter.name}
                            onChange={(e) =>
                              setNewFilter({ ...newFilter, name: e.target.value })
                            }
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label>Filter turi</Label>
                          <Select
                            value={newFilter.type}
                            onValueChange={(value: FilterRule["type"]) =>
                              setNewFilter({ ...newFilter, type: value })
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="card">Karta raqami</SelectItem>
                              <SelectItem value="phone">
                                Telefon raqami
                              </SelectItem>
                              <SelectItem value="username">
                                Telegram username
                              </SelectItem>
                              <SelectItem value="link">Havola (URL)</SelectItem>
                              <SelectItem value="custom">
                                Maxsus (Regex)
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="grid gap-2">
                          <Label>Regex pattern</Label>
                          <Input
                            placeholder="\\d{4}-\\d{4}-\\d{4}-\\d{4}"
                            value={newFilter.pattern}
                            onChange={(e) =>
                              setNewFilter({
                                ...newFilter,
                                pattern: e.target.value,
                              })
                            }
                            className="font-mono text-sm"
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label>Almashtirish matni</Label>
                          <Input
                            placeholder="****-****-****-****"
                            value={newFilter.replacement}
                            onChange={(e) =>
                              setNewFilter({
                                ...newFilter,
                                replacement: e.target.value,
                              })
                            }
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button
                          variant="outline"
                          onClick={() => setIsAddFilterOpen(false)}
                        >
                          Bekor qilish
                        </Button>
                        <Button onClick={handleAddFilter}>Qo'shish</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow className="border-border hover:bg-transparent">
                        <TableHead className="text-muted-foreground">
                          Holat
                        </TableHead>
                        <TableHead className="text-muted-foreground">
                          Nomi
                        </TableHead>
                        <TableHead className="text-muted-foreground">
                          Turi
                        </TableHead>
                        <TableHead className="text-muted-foreground">
                          Pattern
                        </TableHead>
                        <TableHead className="text-muted-foreground">
                          Almashtirish
                        </TableHead>
                        <TableHead className="text-muted-foreground">
                          Topilgan
                        </TableHead>
                        <TableHead className="text-muted-foreground text-right">
                          Amallar
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filters.map((filter) => {
                        const typeConfig = filterTypeConfig[filter.type]
                        const TypeIcon = typeConfig.icon
                        return (
                          <TableRow
                            key={filter.id}
                            className="border-border hover:bg-muted/50"
                          >
                            <TableCell>
                              <Switch
                                checked={filter.enabled}
                                onCheckedChange={() => toggleFilter(filter.id)}
                              />
                            </TableCell>
                            <TableCell className="font-medium text-foreground">
                              {filter.name}
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant="outline"
                                className="border-border"
                              >
                                <TypeIcon
                                  className={`mr-1 h-3 w-3 ${typeConfig.color}`}
                                />
                                {typeConfig.label}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-mono text-xs text-muted-foreground max-w-32 truncate">
                              {filter.pattern}
                            </TableCell>
                            <TableCell className="text-muted-foreground max-w-32 truncate">
                              {filter.replacement}
                            </TableCell>
                            <TableCell className="text-foreground">
                              {filter.matchCount.toLocaleString()}
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8"
                                  >
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>
                                    <Edit className="mr-2 h-4 w-4" />
                                    Tahrirlash
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    className="text-destructive"
                                    onClick={() => deleteFilter(filter.id)}
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    O'chirish
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Replace Tab */}
            <TabsContent value="replace" className="space-y-4">
              <Card className="bg-card border-border">
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle className="text-foreground">
                      Matn almashtirish qoidalari
                    </CardTitle>
                    <CardDescription>
                      Xabarlardagi matnlarni avtomatik almashtirish va
                      tahrirlash
                    </CardDescription>
                  </div>
                  <Dialog
                    open={isAddReplaceOpen}
                    onOpenChange={setIsAddReplaceOpen}
                  >
                    <DialogTrigger asChild>
                      <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                        <Plus className="mr-2 h-4 w-4" />
                        Yangi qoida
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>Yangi almashtirish qoidasi</DialogTitle>
                        <DialogDescription>
                          Matnlarni avtomatik almashtirish uchun qoida yarating.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                          <Label>Qoida nomi</Label>
                          <Input
                            placeholder="Masalan: Kanal nomini almashtirish"
                            value={newReplace.name}
                            onChange={(e) =>
                              setNewReplace({
                                ...newReplace,
                                name: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label>Qidiriladigan matn</Label>
                          <Textarea
                            placeholder="Almashtirilishi kerak bo'lgan matn"
                            value={newReplace.findText}
                            onChange={(e) =>
                              setNewReplace({
                                ...newReplace,
                                findText: e.target.value,
                              })
                            }
                            className="font-mono text-sm"
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label>Yangi matn</Label>
                          <Textarea
                            placeholder="O'rniga qo'yiladigan matn"
                            value={newReplace.replaceText}
                            onChange={(e) =>
                              setNewReplace({
                                ...newReplace,
                                replaceText: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="space-y-4 rounded-lg border border-border p-4">
                          <div className="flex items-center justify-between">
                            <div className="space-y-0.5">
                              <Label>Regex ishlatish</Label>
                              <p className="text-xs text-muted-foreground">
                                Regular expression sifatida qidirish
                              </p>
                            </div>
                            <Switch
                              checked={newReplace.isRegex}
                              onCheckedChange={(checked) =>
                                setNewReplace({
                                  ...newReplace,
                                  isRegex: checked,
                                })
                              }
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="space-y-0.5">
                              <Label>Katta-kichik harf</Label>
                              <p className="text-xs text-muted-foreground">
                                Harflar farqini hisobga olish
                              </p>
                            </div>
                            <Switch
                              checked={newReplace.caseSensitive}
                              onCheckedChange={(checked) =>
                                setNewReplace({
                                  ...newReplace,
                                  caseSensitive: checked,
                                })
                              }
                            />
                          </div>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button
                          variant="outline"
                          onClick={() => setIsAddReplaceOpen(false)}
                        >
                          Bekor qilish
                        </Button>
                        <Button onClick={handleAddReplace}>Qo'shish</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow className="border-border hover:bg-transparent">
                        <TableHead className="text-muted-foreground">
                          Holat
                        </TableHead>
                        <TableHead className="text-muted-foreground">
                          Nomi
                        </TableHead>
                        <TableHead className="text-muted-foreground">
                          Qidirish
                        </TableHead>
                        <TableHead className="text-muted-foreground">
                          Almashtirish
                        </TableHead>
                        <TableHead className="text-muted-foreground">
                          Sozlamalar
                        </TableHead>
                        <TableHead className="text-muted-foreground">
                          Topilgan
                        </TableHead>
                        <TableHead className="text-muted-foreground text-right">
                          Amallar
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {replaces.map((replace) => (
                        <TableRow
                          key={replace.id}
                          className="border-border hover:bg-muted/50"
                        >
                          <TableCell>
                            <Switch
                              checked={replace.enabled}
                              onCheckedChange={() => toggleReplace(replace.id)}
                            />
                          </TableCell>
                          <TableCell className="font-medium text-foreground">
                            {replace.name}
                          </TableCell>
                          <TableCell className="font-mono text-xs text-muted-foreground max-w-32 truncate">
                            {replace.findText}
                          </TableCell>
                          <TableCell className="text-muted-foreground max-w-32 truncate">
                            {replace.replaceText || "(bo'sh)"}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              {replace.isRegex && (
                                <Badge
                                  variant="outline"
                                  className="text-xs border-primary/20 text-primary"
                                >
                                  Regex
                                </Badge>
                              )}
                              {replace.caseSensitive && (
                                <Badge
                                  variant="outline"
                                  className="text-xs border-border"
                                >
                                  Aa
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-foreground">
                            {replace.matchCount.toLocaleString()}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                >
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem>
                                  <Edit className="mr-2 h-4 w-4" />
                                  Tahrirlash
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  className="text-destructive"
                                  onClick={() => deleteReplace(replace.id)}
                                >
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  O'chirish
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
