"use client"

import { useState, useEffect } from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Label } from "@/components/ui/label"
import {
  Plus,
  Search,
  MoreVertical,
  Trash2,
  RefreshCw,
  CheckCircle,
  XCircle,
  Clock,
  Shield,
  Smartphone,
  Loader2,
  Send,
  Key,
  AlertCircle,
  List,
} from "lucide-react"
import { Suspense } from "react"
import Loading from "./loading"

interface Account {
  id: string
  phone: string
  firstName?: string
  lastName?: string
  username?: string
  status: "active" | "inactive" | "banned"
  apiId: number
  createdAt: string
}

const statusConfig = {
  active: {
    label: "Faol",
    icon: CheckCircle,
    className: "bg-success/10 text-success border-success/20",
  },
  inactive: {
    label: "Nofaol",
    icon: XCircle,
    className: "bg-muted text-muted-foreground border-muted",
  },
  banned: {
    label: "Bloklangan",
    icon: Shield,
    className: "bg-destructive/10 text-destructive border-destructive/20",
  },
}

// Login bosqichlari
type LoginStep = "credentials" | "code" | "password" | "success"

export default function AccountsPage() {
  const [accounts, setAccounts] = useState<Account[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingAccounts, setIsLoadingAccounts] = useState(true)
  const [error, setError] = useState<string | null>(null)
  
  // Login form
  const [loginStep, setLoginStep] = useState<LoginStep>("credentials")
  const [sessionId, setSessionId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    phone: "",
    apiId: "",
    apiHash: "",
    code: "",
    password: "",
  })

  // Akkauntlarni yuklash
  useEffect(() => {
    fetchAccounts()
  }, [])

  const fetchAccounts = async () => {
    try {
      setIsLoadingAccounts(true)
      const response = await fetch("/api/telegram/accounts")
      const data = await response.json()

      if (data.accounts) {
        setAccounts(data.accounts)
      }
    } catch (err) {
      console.error("[v0] Akkauntlarni yuklashda xato:", err)
    } finally {
      setIsLoadingAccounts(false)
    }
  }

  const filteredAccounts = accounts.filter(
    (account) =>
      account.phone.includes(searchQuery) ||
      account.firstName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      account.username?.toLowerCase().includes(searchQuery.toLowerCase())
  )

  // 1-bosqich: Kod yuborish
  const handleSendCode = async () => {
    if (!formData.phone || !formData.apiId || !formData.apiHash) {
      setError("Barcha maydonlarni to'ldiring")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/telegram/send-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phone: formData.phone,
          apiId: formData.apiId,
          apiHash: formData.apiHash,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Kod yuborishda xatolik")
      }

      setSessionId(data.sessionId)
      setLoginStep("code")
    } catch (err: any) {
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }

  // 2-bosqich: Kodni tasdiqlash
  const handleVerifyCode = async () => {
    if (!formData.code || !sessionId) {
      setError("Kodni kiriting")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/telegram/verify-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId,
          code: formData.code,
          password: formData.password || undefined,
        }),
      })

      const data = await response.json()

      // 2FA kerak bo'lsa (backend 401 qaytaradi, lekin defensive)
      if (data?.needPassword || data?.error === "2FA_REQUIRED") {
        setLoginStep("password")
        return
      }

      if (!response.ok) {
        throw new Error(data.error || "Tasdiqlashda xatolik")
      }

      // Muvaffaqiyat!
      setLoginStep("success")
      
      // 2 soniyadan keyin dialogni yopish
      setTimeout(() => {
        resetForm()
        fetchAccounts()
      }, 2000)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }

  // 3-bosqich: 2FA parol
  const handleVerifyPassword = async () => {
    if (!formData.password) {
      setError("Parolni kiriting")
      return
    }

    await handleVerifyCode()
  }

  // Formni tozalash
  const resetForm = () => {
    setFormData({
      phone: "",
      apiId: "",
      apiHash: "",
      code: "",
      password: "",
    })
    setLoginStep("credentials")
    setSessionId(null)
    setError(null)
    setIsAddDialogOpen(false)
  }

  // Akkauntni o'chirish
  const handleDeleteAccount = async (id: string) => {
    try {
      const response = await fetch(`/api/telegram/accounts?id=${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setAccounts(accounts.filter((a) => a.id !== id))
      }
    } catch (err) {
      console.error("[v0] O'chirishda xato:", err)
    }
  }

  // Kanallarni yuklash
  const handleLoadChannels = async (accountId: string) => {
    try {
      const response = await fetch(`/api/telegram/dialogs?accountId=${accountId}`)
      const data = await response.json()
      
      if (data.channels) {
        alert(`${data.total} ta kanal topildi!`)
      }
    } catch (err) {
      console.error("[v0] Kanallarni yuklashda xato:", err)
    }
  }

  const activeCount = accounts.filter((a) => a.status === "active").length
  const inactiveCount = accounts.filter((a) => a.status === "inactive").length
  const bannedCount = accounts.filter((a) => a.status === "banned").length

  return (
    <Suspense fallback={<Loading />}>
      <div className="min-h-screen bg-background">
        <Sidebar />
        <main className="pl-64 transition-all duration-300">
          {/* Header */}
          <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-background/95 px-6 backdrop-blur">
            <h1 className="text-xl font-semibold text-foreground">
              Akkauntlar boshqaruvi
            </h1>
            <Dialog open={isAddDialogOpen} onOpenChange={(open) => {
              if (!open) resetForm()
              setIsAddDialogOpen(open)
            }}>
              <DialogTrigger asChild>
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                  <Plus className="mr-2 h-4 w-4" />
                  Yangi akkaunt
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>
                    {loginStep === "credentials" && "Telegram akkaunt qo'shish"}
                    {loginStep === "code" && "Tasdiqlash kodi"}
                    {loginStep === "password" && "Ikki bosqichli parol"}
                    {loginStep === "success" && "Muvaffaqiyat!"}
                  </DialogTitle>
<DialogDescription>
  {loginStep === "credentials" && "API ma'lumotlarini my.telegram.org dan oling"}
  {loginStep === "code" && `${formData.phone} raqamiga Telegram orqali kod yuborildi`}
                    {loginStep === "password" && "Akkauntingiz 2FA bilan himoyalangan"}
                    {loginStep === "success" && "Akkaunt muvaffaqiyatli qo'shildi"}
                  </DialogDescription>
                </DialogHeader>

                {error && (
                  <div className="flex items-center gap-2 rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
                    <AlertCircle className="h-4 w-4" />
                    {error}
                  </div>
                )}

                {/* 1-bosqich: API ma'lumotlari */}
                {loginStep === "credentials" && (
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="phone">Telefon raqam</Label>
                      <Input
                        id="phone"
                        placeholder="+998901234567"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData({ ...formData, phone: e.target.value })
                        }
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="apiId">API ID</Label>
                      <Input
                        id="apiId"
                        placeholder="12345678"
                        value={formData.apiId}
                        onChange={(e) =>
                          setFormData({ ...formData, apiId: e.target.value })
                        }
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="apiHash">API Hash</Label>
                      <Input
                        id="apiHash"
                        placeholder="0123456789abcdef..."
                        type="password"
                        value={formData.apiHash}
                        onChange={(e) =>
                          setFormData({ ...formData, apiHash: e.target.value })
                        }
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">
                      API ma'lumotlarini olish uchun{" "}
                      <a 
                        href="https://my.telegram.org" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        my.telegram.org
                      </a>
                      {" "}saytiga kiring
                    </p>
                  </div>
                )}

                {/* 2-bosqich: Kod kiritish */}
                {loginStep === "code" && (
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="code">Tasdiqlash kodi</Label>
                      <Input
                        id="code"
                        placeholder="12345"
                        maxLength={5}
                        className="text-center text-2xl tracking-widest"
                        value={formData.code}
                        onChange={(e) =>
                          setFormData({ ...formData, code: e.target.value.replace(/\D/g, "") })
                        }
                      />
                    </div>
                    <p className="text-xs text-muted-foreground text-center">
                      Telegram ilovasiga yoki SMS orqali yuborilgan kodni kiriting
                    </p>
                  </div>
                )}

                {/* 3-bosqich: 2FA parol */}
                {loginStep === "password" && (
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="password">2FA Parol</Label>
                      <Input
                        id="password"
                        type="password"
                        placeholder="Ikki bosqichli parolingiz"
                        value={formData.password}
                        onChange={(e) =>
                          setFormData({ ...formData, password: e.target.value })
                        }
                      />
                    </div>
                  </div>
                )}

                {/* 4-bosqich: Muvaffaqiyat */}
                {loginStep === "success" && (
                  <div className="flex flex-col items-center gap-4 py-8">
                    <div className="flex h-16 w-16 items-center justify-center rounded-full bg-success/10">
                      <CheckCircle className="h-8 w-8 text-success" />
                    </div>
                    <p className="text-center text-muted-foreground">
                      Akkaunt muvaffaqiyatli ulandi
                    </p>
                  </div>
                )}

                {loginStep !== "success" && (
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={resetForm}
                      disabled={isLoading}
                    >
                      Bekor qilish
                    </Button>
                    
                    {loginStep === "credentials" && (
                      <Button onClick={handleSendCode} disabled={isLoading}>
                        {isLoading ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <Send className="mr-2 h-4 w-4" />
                        )}
                        Kod yuborish
                      </Button>
                    )}
                    
                    {loginStep === "code" && (
                      <Button onClick={handleVerifyCode} disabled={isLoading}>
                        {isLoading ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <Key className="mr-2 h-4 w-4" />
                        )}
                        Tasdiqlash
                      </Button>
                    )}
                    
                    {loginStep === "password" && (
                      <Button onClick={handleVerifyPassword} disabled={isLoading}>
                        {isLoading ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <Shield className="mr-2 h-4 w-4" />
                        )}
                        Kirish
                      </Button>
                    )}
                  </DialogFooter>
                )}
              </DialogContent>
            </Dialog>
          </header>

          <div className="p-6 space-y-6">
            {/* Stats */}
            <div className="grid gap-4 md:grid-cols-4">
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <Smartphone className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">
                        {accounts.length}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Jami akkauntlar
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                      <CheckCircle className="h-5 w-5 text-success" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">
                        {activeCount}
                      </p>
                      <p className="text-sm text-muted-foreground">Faol</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                      <XCircle className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">
                        {inactiveCount}
                      </p>
                      <p className="text-sm text-muted-foreground">Nofaol</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
                      <Shield className="h-5 w-5 text-destructive" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">
                        {bannedCount}
                      </p>
                      <p className="text-sm text-muted-foreground">Bloklangan</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Accounts Table */}
            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-foreground">
                  Barcha akkauntlar
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={fetchAccounts}
                    disabled={isLoadingAccounts}
                  >
                    <RefreshCw className={`mr-2 h-4 w-4 ${isLoadingAccounts ? "animate-spin" : ""}`} />
                    Yangilash
                  </Button>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Qidirish..."
                      className="w-64 bg-muted/50 pl-9 border-border"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingAccounts ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : accounts.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <Smartphone className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium text-foreground">Akkauntlar yo'q</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Birinchi Telegram akkauntingizni qo'shing
                    </p>
                    <Button 
                      className="mt-4"
                      onClick={() => setIsAddDialogOpen(true)}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Akkaunt qo'shish
                    </Button>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow className="border-border hover:bg-transparent">
                        <TableHead className="text-muted-foreground">Foydalanuvchi</TableHead>
                        <TableHead className="text-muted-foreground">
                          Telefon
                        </TableHead>
                        <TableHead className="text-muted-foreground">Holat</TableHead>
                        <TableHead className="text-muted-foreground">
                          API ID
                        </TableHead>
                        <TableHead className="text-muted-foreground">
                          Qo'shilgan sana
                        </TableHead>
                        <TableHead className="text-muted-foreground text-right">
                          Amallar
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredAccounts.map((account) => {
                        const status = statusConfig[account.status]
                        const StatusIcon = status.icon
                        const displayName = account.firstName 
                          ? `${account.firstName} ${account.lastName || ""}`.trim()
                          : account.username || "Nomsiz"
                        
                        return (
                          <TableRow
                            key={account.id}
                            className="border-border hover:bg-muted/50"
                          >
                            <TableCell className="font-medium text-foreground">
                              <div>
                                <p>{displayName}</p>
                                {account.username && (
                                  <p className="text-xs text-muted-foreground">
                                    @{account.username}
                                  </p>
                                )}
                              </div>
                            </TableCell>
                            <TableCell className="text-muted-foreground font-mono">
                              {account.phone}
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant="outline"
                                className={status.className}
                              >
                                <StatusIcon className="mr-1 h-3 w-3" />
                                {status.label}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-muted-foreground font-mono">
                              {account.apiId}
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              {new Date(account.createdAt).toLocaleDateString("uz-UZ")}
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8"
                                  >
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem 
                                    onClick={() => handleLoadChannels(account.id)}
                                  >
                                    <List className="mr-2 h-4 w-4" />
                                    Kanallarni yuklash
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    className="text-destructive"
                                    onClick={() => handleDeleteAccount(account.id)}
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    O'chirish
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </Suspense>
  )
}
