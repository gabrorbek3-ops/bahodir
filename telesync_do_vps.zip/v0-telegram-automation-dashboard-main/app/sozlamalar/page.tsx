"use client"

import { useState } from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Settings,
  Globe,
  Shield,
  Bell,
  Database,
  Zap,
  Moon,
  Sun,
  Save,
  RefreshCw,
} from "lucide-react"

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    language: "uz",
    theme: "dark",
    autoRotation: true,
    floodWaitHandling: true,
    sessionEncryption: true,
    notifications: true,
    emailNotifications: false,
    maxConcurrentTasks: "3",
    defaultImportMode: "fast",
    retryAttempts: "3",
    logRetentionDays: "30",
  })

  const handleSave = () => {
    // Save settings logic would go here
    console.log("Settings saved:", settings)
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="pl-64 transition-all duration-300">
        {/* Header */}
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-background/95 px-6 backdrop-blur">
          <h1 className="text-xl font-semibold text-foreground">Sozlamalar</h1>
          <Button
            onClick={handleSave}
            className="bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <Save className="mr-2 h-4 w-4" />
            Saqlash
          </Button>
        </header>

        <div className="p-6 space-y-6">
          <Tabs defaultValue="general" className="space-y-4">
            <TabsList className="bg-muted">
              <TabsTrigger value="general">Umumiy</TabsTrigger>
              <TabsTrigger value="security">Xavfsizlik</TabsTrigger>
              <TabsTrigger value="import">Import sozlamalari</TabsTrigger>
              <TabsTrigger value="notifications">Bildirishnomalar</TabsTrigger>
            </TabsList>

            {/* General Settings */}
            <TabsContent value="general" className="space-y-4">
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground flex items-center gap-2">
                    <Globe className="h-5 w-5 text-primary" />
                    Umumiy sozlamalar
                  </CardTitle>
                  <CardDescription>
                    Til, tema va asosiy sozlamalarni boshqaring
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Til</Label>
                      <Select
                        value={settings.language}
                        onValueChange={(value) =>
                          setSettings({ ...settings, language: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="uz">O'zbek</SelectItem>
                          <SelectItem value="ru">Русский</SelectItem>
                          <SelectItem value="en">English</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Tema</Label>
                      <Select
                        value={settings.theme}
                        onValueChange={(value) =>
                          setSettings({ ...settings, theme: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="dark">
                            <div className="flex items-center">
                              <Moon className="mr-2 h-4 w-4" />
                              Qorong'i
                            </div>
                          </SelectItem>
                          <SelectItem value="light">
                            <div className="flex items-center">
                              <Sun className="mr-2 h-4 w-4" />
                              Yorug'
                            </div>
                          </SelectItem>
                          <SelectItem value="system">
                            <div className="flex items-center">
                              <Settings className="mr-2 h-4 w-4" />
                              Tizim
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Log saqlash muddati (kun)</Label>
                    <Input
                      type="number"
                      value={settings.logRetentionDays}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          logRetentionDays: e.target.value,
                        })
                      }
                      className="max-w-xs"
                    />
                    <p className="text-xs text-muted-foreground">
                      Loglar ushbu muddatdan keyin avtomatik o'chiriladi
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Security Settings */}
            <TabsContent value="security" className="space-y-4">
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground flex items-center gap-2">
                    <Shield className="h-5 w-5 text-success" />
                    Xavfsizlik sozlamalari
                  </CardTitle>
                  <CardDescription>
                    Akkaunt xavfsizligi va ma'lumotlar himoyasi
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between rounded-lg border border-border p-4">
                      <div className="space-y-0.5">
                        <Label>Sessiya shifrlash</Label>
                        <p className="text-sm text-muted-foreground">
                          Telegram sessiya fayllarini shifrlash
                        </p>
                      </div>
                      <Switch
                        checked={settings.sessionEncryption}
                        onCheckedChange={(checked) =>
                          setSettings({ ...settings, sessionEncryption: checked })
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between rounded-lg border border-border p-4">
                      <div className="space-y-0.5">
                        <Label>Avtomatik akkaunt almashinuvi</Label>
                        <p className="text-sm text-muted-foreground">
                          Flood wait holatida boshqa akkauntga o'tish
                        </p>
                      </div>
                      <Switch
                        checked={settings.autoRotation}
                        onCheckedChange={(checked) =>
                          setSettings({ ...settings, autoRotation: checked })
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between rounded-lg border border-border p-4">
                      <div className="space-y-0.5">
                        <Label>Flood wait boshqaruvi</Label>
                        <p className="text-sm text-muted-foreground">
                          Telegram cheklovlarini avtomatik boshqarish
                        </p>
                      </div>
                      <Switch
                        checked={settings.floodWaitHandling}
                        onCheckedChange={(checked) =>
                          setSettings({ ...settings, floodWaitHandling: checked })
                        }
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Import Settings */}
            <TabsContent value="import" className="space-y-4">
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground flex items-center gap-2">
                    <Zap className="h-5 w-5 text-warning" />
                    Import sozlamalari
                  </CardTitle>
                  <CardDescription>
                    Import vazifalarining standart sozlamalari
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Bir vaqtda faol vazifalar</Label>
                      <Select
                        value={settings.maxConcurrentTasks}
                        onValueChange={(value) =>
                          setSettings({ ...settings, maxConcurrentTasks: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 ta</SelectItem>
                          <SelectItem value="2">2 ta</SelectItem>
                          <SelectItem value="3">3 ta</SelectItem>
                          <SelectItem value="5">5 ta</SelectItem>
                          <SelectItem value="10">10 ta</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Standart import rejimi</Label>
                      <Select
                        value={settings.defaultImportMode}
                        onValueChange={(value) =>
                          setSettings({ ...settings, defaultImportMode: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="fast">Tez rejim</SelectItem>
                          <SelectItem value="realtime">
                            Real vaqt simulyatsiyasi
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Xato qayta urinishlar soni</Label>
                    <Select
                      value={settings.retryAttempts}
                      onValueChange={(value) =>
                        setSettings({ ...settings, retryAttempts: value })
                      }
                    >
                      <SelectTrigger className="max-w-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 marta</SelectItem>
                        <SelectItem value="3">3 marta</SelectItem>
                        <SelectItem value="5">5 marta</SelectItem>
                        <SelectItem value="10">10 marta</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      Xato yuz berganda vazifani qayta urinishlar soni
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notification Settings */}
            <TabsContent value="notifications" className="space-y-4">
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground flex items-center gap-2">
                    <Bell className="h-5 w-5 text-primary" />
                    Bildirishnoma sozlamalari
                  </CardTitle>
                  <CardDescription>
                    Bildirishnomalar va ogohlantirishlarni boshqaring
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between rounded-lg border border-border p-4">
                      <div className="space-y-0.5">
                        <Label>Brauzer bildirishnomalari</Label>
                        <p className="text-sm text-muted-foreground">
                          Vazifalar yakunlanganda yoki xato yuz berganda xabar
                          olish
                        </p>
                      </div>
                      <Switch
                        checked={settings.notifications}
                        onCheckedChange={(checked) =>
                          setSettings({ ...settings, notifications: checked })
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between rounded-lg border border-border p-4">
                      <div className="space-y-0.5">
                        <Label>Email bildirishnomalari</Label>
                        <p className="text-sm text-muted-foreground">
                          Muhim hodisalar haqida emailga xabar yuborish
                        </p>
                      </div>
                      <Switch
                        checked={settings.emailNotifications}
                        onCheckedChange={(checked) =>
                          setSettings({ ...settings, emailNotifications: checked })
                        }
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
