"use client"

import { useState } from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Plus,
  Search,
  MoreVertical,
  Trash2,
  Link2,
  ArrowRight,
  Radio,
  Users,
  Lock,
  Globe,
  RefreshCw,
} from "lucide-react"
import { useSearchParams } from "next/navigation"
import { Suspense } from "react"
import Loading from "./loading"

interface Channel {
  id: number
  name: string
  username: string
  type: "channel" | "group"
  access: "public" | "private"
  membersCount: number
  messagesCount: number
  linkedAccount: string
  addedDate: string
}

interface ChannelMapping {
  id: number
  sourceChannel: string
  destChannel: string
  account: string
  status: "active" | "paused" | "completed"
  importedMessages: number
  totalMessages: number
}

const initialChannels: Channel[] = [
  {
    id: 1,
    name: "Crypto News UZ",
    username: "@crypto_news_uz",
    type: "channel",
    access: "public",
    membersCount: 125000,
    messagesCount: 15000,
    linkedAccount: "Asosiy akkaunt",
    addedDate: "2024-01-01",
  },
  {
    id: 2,
    name: "Texnologiya Yangiliklari",
    username: "@tech_updates",
    type: "channel",
    access: "public",
    membersCount: 85000,
    messagesCount: 8500,
    linkedAccount: "Zaxira akkaunt 1",
    addedDate: "2024-01-05",
  },
  {
    id: 3,
    name: "Dunyo Yangiliklari",
    username: "@world_news",
    type: "channel",
    access: "private",
    membersCount: 45000,
    messagesCount: 25000,
    linkedAccount: "Import akkaunt",
    addedDate: "2024-01-08",
  },
  {
    id: 4,
    name: "Dasturchilar Guruhi",
    username: "@dev_group_uz",
    type: "group",
    access: "public",
    membersCount: 12500,
    messagesCount: 67000,
    linkedAccount: "Asosiy akkaunt",
    addedDate: "2024-01-10",
  },
]

const initialMappings: ChannelMapping[] = [
  {
    id: 1,
    sourceChannel: "@crypto_news_uz",
    destChannel: "@my_crypto_channel",
    account: "Asosiy akkaunt",
    status: "active",
    importedMessages: 10050,
    totalMessages: 15000,
  },
  {
    id: 2,
    sourceChannel: "@tech_updates",
    destChannel: "@texnologiya_yangiliklari",
    account: "Zaxira akkaunt 1",
    status: "paused",
    importedMessages: 2890,
    totalMessages: 8500,
  },
  {
    id: 3,
    sourceChannel: "@world_news",
    destChannel: "@dunyo_yangiliklari",
    account: "Import akkaunt",
    status: "completed",
    importedMessages: 25000,
    totalMessages: 25000,
  },
]

const statusConfig = {
  active: {
    label: "Faol",
    className: "bg-success/10 text-success border-success/20",
  },
  paused: {
    label: "To'xtatilgan",
    className: "bg-warning/10 text-warning border-warning/20",
  },
  completed: {
    label: "Yakunlangan",
    className: "bg-primary/10 text-primary border-primary/20",
  },
}

export default function ChannelsPage() {
  const [channels, setChannels] = useState<Channel[]>(initialChannels)
  const [mappings, setMappings] = useState<ChannelMapping[]>(initialMappings)
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddChannelOpen, setIsAddChannelOpen] = useState(false)
  const [isAddMappingOpen, setIsAddMappingOpen] = useState(false)
  const [newChannel, setNewChannel] = useState({
    username: "",
    account: "",
  })
  const [newMapping, setNewMapping] = useState({
    source: "",
    destination: "",
    account: "",
  })

  const filteredChannels = channels.filter(
    (channel) =>
      channel.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      channel.username.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const handleAddChannel = () => {
    // Simulate adding channel
    setIsAddChannelOpen(false)
    setNewChannel({ username: "", account: "" })
  }

  const handleAddMapping = () => {
    const newId = Math.max(...mappings.map((m) => m.id)) + 1
    const mapping: ChannelMapping = {
      id: newId,
      sourceChannel: newMapping.source,
      destChannel: newMapping.destination,
      account: newMapping.account,
      status: "active",
      importedMessages: 0,
      totalMessages: 0,
    }
    setMappings([...mappings, mapping])
    setIsAddMappingOpen(false)
    setNewMapping({ source: "", destination: "", account: "" })
  }

  const handleDeleteChannel = (id: number) => {
    setChannels(channels.filter((c) => c.id !== id))
  }

  const handleDeleteMapping = (id: number) => {
    setMappings(mappings.filter((m) => m.id !== id))
  }

  return (
    <Suspense fallback={<Loading />}>
      <div className="min-h-screen bg-background">
        <Sidebar />
        <main className="pl-64 transition-all duration-300">
          {/* Header */}
          <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-background/95 px-6 backdrop-blur">
            <h1 className="text-xl font-semibold text-foreground">
              Kanallar boshqaruvi
            </h1>
          </header>

          <div className="p-6 space-y-6">
            {/* Stats */}
            <div className="grid gap-4 md:grid-cols-4">
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <Radio className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">
                        {channels.filter((c) => c.type === "channel").length}
                      </p>
                      <p className="text-sm text-muted-foreground">Kanallar</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                      <Users className="h-5 w-5 text-accent" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">
                        {channels.filter((c) => c.type === "group").length}
                      </p>
                      <p className="text-sm text-muted-foreground">Guruhlar</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                      <Link2 className="h-5 w-5 text-success" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">
                        {mappings.length}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Ulanishlar
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/10">
                      <Globe className="h-5 w-5 text-warning" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">
                        {channels
                          .reduce((acc, c) => acc + c.membersCount, 0)
                          .toLocaleString()}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Jami a'zolar
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Tabs */}
            <Tabs defaultValue="channels" className="space-y-4">
              <TabsList className="bg-muted">
                <TabsTrigger value="channels">Kanallar ro'yxati</TabsTrigger>
                <TabsTrigger value="mappings">Kanal ulanishlari</TabsTrigger>
              </TabsList>

              {/* Channels Tab */}
              <TabsContent value="channels" className="space-y-4">
                <Card className="bg-card border-border">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="text-foreground">
                      Ulangan kanallar
                    </CardTitle>
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                        <Input
                          placeholder="Qidirish..."
                          className="w-64 bg-muted/50 pl-9 border-border"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                        />
                      </div>
                      <Dialog
                        open={isAddChannelOpen}
                        onOpenChange={setIsAddChannelOpen}
                      >
                        <DialogTrigger asChild>
                          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                            <Plus className="mr-2 h-4 w-4" />
                            Kanal qo'shish
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-md">
                          <DialogHeader>
                            <DialogTitle>Yangi kanal qo'shish</DialogTitle>
                            <DialogDescription>
                              Telegram kanal yoki guruhini qo'shing.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="grid gap-4 py-4">
                            <div className="grid gap-2">
                              <Label htmlFor="channelUsername">
                                Kanal username yoki havolasi
                              </Label>
                              <Input
                                id="channelUsername"
                                placeholder="@channel_username yoki t.me/..."
                                value={newChannel.username}
                                onChange={(e) =>
                                  setNewChannel({
                                    ...newChannel,
                                    username: e.target.value,
                                  })
                                }
                              />
                            </div>
                            <div className="grid gap-2">
                              <Label>Bog'lanadigan akkaunt</Label>
                              <Select
                                value={newChannel.account}
                                onValueChange={(value) =>
                                  setNewChannel({ ...newChannel, account: value })
                                }
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Akkauntni tanlang" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="account1">
                                    Asosiy akkaunt
                                  </SelectItem>
                                  <SelectItem value="account2">
                                    Zaxira akkaunt 1
                                  </SelectItem>
                                  <SelectItem value="account3">
                                    Import akkaunt
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button
                              variant="outline"
                              onClick={() => setIsAddChannelOpen(false)}
                            >
                              Bekor qilish
                            </Button>
                            <Button onClick={handleAddChannel}>Qo'shish</Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow className="border-border hover:bg-transparent">
                          <TableHead className="text-muted-foreground">
                            Kanal nomi
                          </TableHead>
                          <TableHead className="text-muted-foreground">
                            Turi
                          </TableHead>
                          <TableHead className="text-muted-foreground">
                            Kirish
                          </TableHead>
                          <TableHead className="text-muted-foreground">
                            A'zolar
                          </TableHead>
                          <TableHead className="text-muted-foreground">
                            Xabarlar
                          </TableHead>
                          <TableHead className="text-muted-foreground">
                            Bog'langan akkaunt
                          </TableHead>
                          <TableHead className="text-muted-foreground text-right">
                            Amallar
                          </TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredChannels.map((channel) => (
                          <TableRow
                            key={channel.id}
                            className="border-border hover:bg-muted/50"
                          >
                            <TableCell>
                              <div>
                                <p className="font-medium text-foreground">
                                  {channel.name}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                  {channel.username}
                                </p>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant="outline"
                                className="border-border text-muted-foreground"
                              >
                                {channel.type === "channel" ? (
                                  <Radio className="mr-1 h-3 w-3" />
                                ) : (
                                  <Users className="mr-1 h-3 w-3" />
                                )}
                                {channel.type === "channel" ? "Kanal" : "Guruh"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant="outline"
                                className={
                                  channel.access === "public"
                                    ? "border-success/20 text-success"
                                    : "border-warning/20 text-warning"
                                }
                              >
                                {channel.access === "public" ? (
                                  <Globe className="mr-1 h-3 w-3" />
                                ) : (
                                  <Lock className="mr-1 h-3 w-3" />
                                )}
                                {channel.access === "public"
                                  ? "Ochiq"
                                  : "Yopiq"}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-foreground">
                              {channel.membersCount.toLocaleString()}
                            </TableCell>
                            <TableCell className="text-foreground">
                              {channel.messagesCount.toLocaleString()}
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              {channel.linkedAccount}
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8"
                                  >
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>
                                    <RefreshCw className="mr-2 h-4 w-4" />
                                    Yangilash
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    className="text-destructive"
                                    onClick={() =>
                                      handleDeleteChannel(channel.id)
                                    }
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    O'chirish
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Mappings Tab */}
              <TabsContent value="mappings" className="space-y-4">
                <Card className="bg-card border-border">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="text-foreground">
                      Kanal ulanishlari (Manba → Maqsad)
                    </CardTitle>
                    <Dialog
                      open={isAddMappingOpen}
                      onOpenChange={setIsAddMappingOpen}
                    >
                      <DialogTrigger asChild>
                        <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                          <Plus className="mr-2 h-4 w-4" />
                          Yangi ulanish
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-md">
                        <DialogHeader>
                          <DialogTitle>Yangi ulanish yaratish</DialogTitle>
                          <DialogDescription>
                            Manba kanaldan maqsad kanalga xabarlarni ko'chirish
                            uchun ulanish yarating.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label>Manba kanal</Label>
                            <Select
                              value={newMapping.source}
                              onValueChange={(value) =>
                                setNewMapping({ ...newMapping, source: value })
                              }
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Manba kanalni tanlang" />
                              </SelectTrigger>
                              <SelectContent>
                                {channels.map((c) => (
                                  <SelectItem key={c.id} value={c.username}>
                                    {c.name} ({c.username})
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex justify-center">
                            <ArrowRight className="h-5 w-5 text-muted-foreground" />
                          </div>
                          <div className="grid gap-2">
                            <Label>Maqsad kanal</Label>
                            <Input
                              placeholder="@target_channel"
                              value={newMapping.destination}
                              onChange={(e) =>
                                setNewMapping({
                                  ...newMapping,
                                  destination: e.target.value,
                                })
                              }
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label>Post qiladigan akkaunt</Label>
                            <Select
                              value={newMapping.account}
                              onValueChange={(value) =>
                                setNewMapping({ ...newMapping, account: value })
                              }
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Akkauntni tanlang" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Asosiy akkaunt">
                                  Asosiy akkaunt
                                </SelectItem>
                                <SelectItem value="Zaxira akkaunt 1">
                                  Zaxira akkaunt 1
                                </SelectItem>
                                <SelectItem value="Import akkaunt">
                                  Import akkaunt
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button
                            variant="outline"
                            onClick={() => setIsAddMappingOpen(false)}
                          >
                            Bekor qilish
                          </Button>
                          <Button onClick={handleAddMapping}>Yaratish</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow className="border-border hover:bg-transparent">
                          <TableHead className="text-muted-foreground">
                            Manba kanal
                          </TableHead>
                          <TableHead className="text-muted-foreground"></TableHead>
                          <TableHead className="text-muted-foreground">
                            Maqsad kanal
                          </TableHead>
                          <TableHead className="text-muted-foreground">
                            Akkaunt
                          </TableHead>
                          <TableHead className="text-muted-foreground">
                            Holat
                          </TableHead>
                          <TableHead className="text-muted-foreground">
                            Progress
                          </TableHead>
                          <TableHead className="text-muted-foreground text-right">
                            Amallar
                          </TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {mappings.map((mapping) => {
                          const status = statusConfig[mapping.status]
                          const progress =
                            mapping.totalMessages > 0
                              ? Math.round(
                                  (mapping.importedMessages /
                                    mapping.totalMessages) *
                                    100
                                )
                              : 0
                          return (
                            <TableRow
                              key={mapping.id}
                              className="border-border hover:bg-muted/50"
                            >
                              <TableCell className="font-medium text-foreground">
                                {mapping.sourceChannel}
                              </TableCell>
                              <TableCell>
                                <ArrowRight className="h-4 w-4 text-muted-foreground" />
                              </TableCell>
                              <TableCell className="font-medium text-foreground">
                                {mapping.destChannel}
                              </TableCell>
                              <TableCell className="text-muted-foreground">
                                {mapping.account}
                              </TableCell>
                              <TableCell>
                                <Badge
                                  variant="outline"
                                  className={status.className}
                                >
                                  {status.label}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <div className="h-2 w-24 rounded-full bg-muted overflow-hidden">
                                    <div
                                      className="h-full bg-primary"
                                      style={{ width: `${progress}%` }}
                                    />
                                  </div>
                                  <span className="text-sm text-muted-foreground">
                                    {progress}%
                                  </span>
                                </div>
                              </TableCell>
                              <TableCell className="text-right">
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-8 w-8"
                                    >
                                      <MoreVertical className="h-4 w-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuItem
                                      className="text-destructive"
                                      onClick={() =>
                                        handleDeleteMapping(mapping.id)
                                      }
                                    >
                                      <Trash2 className="mr-2 h-4 w-4" />
                                      O'chirish
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </TableCell>
                            </TableRow>
                          )
                        })}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </Suspense>
  )
}
