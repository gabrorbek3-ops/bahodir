"use client"

import { Sidebar } from "@/components/dashboard/sidebar"
import { Header } from "@/components/dashboard/header"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { ActiveTasks } from "@/components/dashboard/active-tasks"
import { RecentLogs } from "@/components/dashboard/recent-logs"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="pl-64 transition-all duration-300">
        <Header />
        <div className="p-6 space-y-6">
          {/* Stats Section */}
          <section>
            <h2 className="text-lg font-semibold text-foreground mb-4">
              Umumiy statistika
            </h2>
            <StatsCards />
          </section>

          {/* Main Content Grid */}
          <div className="grid gap-6 lg:grid-cols-2">
            <ActiveTasks />
            <RecentLogs />
          </div>
        </div>
      </main>
    </div>
  )
}
