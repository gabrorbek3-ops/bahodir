import { NextResponse } from "next/server"
import { queryOne } from "@/lib/db"

// Dashboard statistikasi
export async function GET() {
  try {
    // Akkauntlar soni
    const accountsResult = await queryOne<any>(
      "SELECT COUNT(*) as count FROM accounts WHERE status = 'active'"
    )

    // Kanallar soni
    const channelsResult = await queryOne<any>(
      "SELECT COUNT(*) as count FROM channels"
    )

    // Faol mappinglar soni
    const mappingsResult = await queryOne<any>(
      "SELECT COUNT(*) as count FROM channel_mappings WHERE is_active = true"
    )

    // Faol vazifalar soni
    const tasksResult = await queryOne<any>(
      "SELECT COUNT(*) as count FROM import_tasks WHERE status = 'running'"
    )

    // Bugungi xabarlar (agar kerak bo'lsa)
    const todayMessagesResult = await queryOne<any>(
      `SELECT COALESCE(SUM(processed_messages), 0) as count FROM import_tasks 
       WHERE DATE(created_at) = CURRENT_DATE`
    )

    return NextResponse.json({
      stats: {
        accounts: parseInt(accountsResult?.count || "0"),
        channels: parseInt(channelsResult?.count || "0"),
        mappings: parseInt(mappingsResult?.count || "0"),
        activeTasks: parseInt(tasksResult?.count || "0"),
        todayMessages: parseInt(todayMessagesResult?.count || "0"),
      }
    })
  } catch (error: any) {
    console.error("[v0] Stats GET xatosi:", error)
    return NextResponse.json({ 
      stats: {
        accounts: 0,
        channels: 0,
        mappings: 0,
        activeTasks: 0,
        todayMessages: 0,
      }
    })
  }
}
