import { NextRequest, NextResponse } from "next/server"
import { query, queryOne, execute, addLog } from "@/lib/db"

// Barcha mappinglarni olish
export async function GET() {
  try {
    const mappings = await query(
      `SELECT * FROM channel_mappings ORDER BY created_at DESC`
    )
    return NextResponse.json({ mappings })
  } catch (error: any) {
    console.error("[v0] Mappings GET xatosi:", error)
    return NextResponse.json({ error: "Mappinglarni olishda xatolik" }, { status: 500 })
  }
}

// Yangi mapping yaratish
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      sourceChannelId,
      sourceTitle,
      targetChannelId,
      targetTitle,
      accountId,
      copyMedia = true,
      copyText = true,
      removeLinks = false,
      addWatermark = false,
      watermarkText = "",
    } = body

    if (!sourceChannelId || !targetChannelId || !accountId) {
      return NextResponse.json(
        { error: "Manba kanal, maqsad kanal va akkaunt kerak" },
        { status: 400 }
      )
    }

    const mappingId = `map_${Date.now()}`
    await execute(
      `INSERT INTO channel_mappings 
       (id, source_channel_id, source_title, target_channel_id, target_title, account_id, copy_media, copy_text, remove_links, add_watermark, watermark_text)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
      [
        mappingId,
        sourceChannelId,
        sourceTitle || "",
        targetChannelId,
        targetTitle || "",
        accountId,
        copyMedia,
        copyText,
        removeLinks,
        addWatermark,
        watermarkText,
      ]
    )

    await addLog("info", `Kanal bog'landi: ${sourceTitle} -> ${targetTitle}`)

    return NextResponse.json({
      success: true,
      mappingId,
      message: "Kanal bog'landi",
    })
  } catch (error: any) {
    console.error("[v0] Mappings POST xatosi:", error)
    return NextResponse.json({ error: "Mapping yaratishda xatolik" }, { status: 500 })
  }
}

// Mapping o'chirish
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Mapping ID kerak" }, { status: 400 })
    }

    await execute("DELETE FROM channel_mappings WHERE id = $1", [id])
    await addLog("info", `Kanal bog'lanishi o'chirildi: ${id}`)

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("[v0] Mappings DELETE xatosi:", error)
    return NextResponse.json({ error: "O'chirishda xatolik" }, { status: 500 })
  }
}

// Mapping yangilash
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, isActive, copyMedia, copyText, removeLinks, addWatermark, watermarkText } = body

    if (!id) {
      return NextResponse.json({ error: "Mapping ID kerak" }, { status: 400 })
    }

    await execute(
      `UPDATE channel_mappings SET 
       is_active = COALESCE($2, is_active),
       copy_media = COALESCE($3, copy_media),
       copy_text = COALESCE($4, copy_text),
       remove_links = COALESCE($5, remove_links),
       add_watermark = COALESCE($6, add_watermark),
       watermark_text = COALESCE($7, watermark_text),
       updated_at = NOW()
       WHERE id = $1`,
      [id, isActive, copyMedia, copyText, removeLinks, addWatermark, watermarkText]
    )

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("[v0] Mappings PATCH xatosi:", error)
    return NextResponse.json({ error: "Yangilashda xatolik" }, { status: 500 })
  }
}
