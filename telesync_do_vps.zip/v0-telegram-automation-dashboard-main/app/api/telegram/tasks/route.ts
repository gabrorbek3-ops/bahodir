import { NextRequest, NextResponse } from "next/server"
import { query, queryOne, execute, addLog } from "@/lib/db"

// Barcha vazifalarni olish
export async function GET() {
  try {
    const tasks = await query(
      `SELECT * FROM import_tasks ORDER BY created_at DESC`
    )
    return NextResponse.json({ tasks })
  } catch (error: any) {
    console.error("[v0] Tasks GET xatosi:", error)
    return NextResponse.json({ error: "Vazifalarni olishda xatolik" }, { status: 500 })
  }
}

// Yangi vazifa yaratish
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      name,
      sourceChannelId,
      sourceTitle,
      targetChannelId,
      targetTitle,
      accountId,
      startDate,
      endDate,
    } = body

    if (!name || !sourceChannelId || !targetChannelId || !accountId) {
      return NextResponse.json(
        { error: "Nomi, manba kanal, maqsad kanal va akkaunt kerak" },
        { status: 400 }
      )
    }

    const taskId = `task_${Date.now()}`
    await execute(
      `INSERT INTO import_tasks 
       (id, name, source_channel_id, source_title, target_channel_id, target_title, account_id, start_date, end_date, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'pending')`,
      [
        taskId,
        name,
        sourceChannelId,
        sourceTitle || "",
        targetChannelId,
        targetTitle || "",
        accountId,
        startDate || null,
        endDate || null,
      ]
    )

    await addLog("info", `Yangi import vazifasi yaratildi: ${name}`)

    return NextResponse.json({
      success: true,
      taskId,
      message: "Vazifa yaratildi",
    })
  } catch (error: any) {
    console.error("[v0] Tasks POST xatosi:", error)
    return NextResponse.json({ error: "Vazifa yaratishda xatolik" }, { status: 500 })
  }
}

// Vazifa o'chirish
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Vazifa ID kerak" }, { status: 400 })
    }

    await execute("DELETE FROM import_tasks WHERE id = $1", [id])
    await addLog("info", `Import vazifasi o'chirildi: ${id}`)

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("[v0] Tasks DELETE xatosi:", error)
    return NextResponse.json({ error: "O'chirishda xatolik" }, { status: 500 })
  }
}

// Vazifa statusini yangilash
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, status, progress, processedMessages, errorMessage } = body

    if (!id) {
      return NextResponse.json({ error: "Vazifa ID kerak" }, { status: 400 })
    }

    await execute(
      `UPDATE import_tasks SET 
       status = COALESCE($2, status),
       progress = COALESCE($3, progress),
       processed_messages = COALESCE($4, processed_messages),
       error_message = COALESCE($5, error_message),
       updated_at = NOW()
       WHERE id = $1`,
      [id, status, progress, processedMessages, errorMessage]
    )

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("[v0] Tasks PATCH xatosi:", error)
    return NextResponse.json({ error: "Yangilashda xatolik" }, { status: 500 })
  }
}
