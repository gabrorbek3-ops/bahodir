import { NextRequest, NextResponse } from "next/server"
import { query, execute } from "@/lib/db"

// So'nggi loglarni olish
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = parseInt(searchParams.get("limit") || "50")
    const level = searchParams.get("level")

    let sql = `SELECT * FROM logs`
    const params: any[] = []

    if (level && level !== "all") {
      sql += ` WHERE level = $1`
      params.push(level)
    }

    sql += ` ORDER BY created_at DESC LIMIT ${limit}`

    const logs = await query(sql, params)
    return NextResponse.json({ logs })
  } catch (error: any) {
    console.error("[v0] Logs GET xatosi:", error)
    return NextResponse.json({ error: "Loglarni olishda xatolik" }, { status: 500 })
  }
}

// Loglarni tozalash
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const days = parseInt(searchParams.get("days") || "7")

    await execute(
      `DELETE FROM logs WHERE created_at < NOW() - INTERVAL '${days} days'`
    )

    return NextResponse.json({ success: true, message: `${days} kundan eski loglar o'chirildi` })
  } catch (error: any) {
    console.error("[v0] Logs DELETE xatosi:", error)
    return NextResponse.json({ error: "Loglarni o'chirishda xatolik" }, { status: 500 })
  }
}
