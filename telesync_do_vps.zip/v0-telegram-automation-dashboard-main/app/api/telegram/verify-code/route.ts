import { NextRequest, NextResponse } from "next/server"
import { queryOne, execute, addLog } from "@/lib/db"
import { activeClients } from "../send-code/route"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { sessionId, code, password } = body

    // Validatsiya
    if (!sessionId || !code) {
      return NextResponse.json(
        { error: "Session ID va kod kerak" },
        { status: 400 }
      )
    }

    // Pending auth olish
    const pendingAuth = await queryOne<any>(
      "SELECT * FROM pending_auth WHERE session_id = $1 AND expires_at > NOW()",
      [sessionId]
    )

    if (!pendingAuth) {
      return NextResponse.json(
        { error: "Sessiya topilmadi yoki muddati o'tgan" },
        { status: 400 }
      )
    }

    // Clientni olish
    const client = activeClients.get(sessionId)
    if (!client) {
      return NextResponse.json(
        { error: "Ulanish topilmadi. Qaytadan kod yuborishingiz kerak" },
        { status: 400 }
      )
    }

    const { Api } = await import("telegram")
    const { phone, api_id, api_hash, phone_code_hash } = pendingAuth

    try {
      // Kodni tasdiqlash
      const result = await client.invoke(
        new Api.auth.SignIn({
          phoneNumber: phone,
          phoneCodeHash: phone_code_hash,
          phoneCode: code,
        })
      )

      if (result instanceof Api.auth.AuthorizationSignUpRequired) {
        return NextResponse.json(
          { error: "Bu telefon raqam Telegramda ro'yxatdan o'tmagan" },
          { status: 400 }
        )
      }

      const user = (result as any).user
      const session = client.session.save() as unknown as string

      // Akkauntni database ga saqlash
      const accountId = `acc_${Date.now()}`
      await execute(
        `INSERT INTO accounts (id, phone, api_id, api_hash, session, first_name, last_name, username, status)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'active')
         ON CONFLICT (phone) DO UPDATE SET
         session = $5, first_name = $6, last_name = $7, username = $8, status = 'active', updated_at = NOW()`,
        [
          accountId,
          phone,
          api_id,
          api_hash,
          session,
          user?.firstName || "",
          user?.lastName || "",
          user?.username || "",
        ]
      )

      // Tozalash
      await execute("DELETE FROM pending_auth WHERE session_id = $1", [sessionId])
      activeClients.delete(sessionId)
      await client.disconnect()

      await addLog("success", `Akkaunt qo'shildi: ${phone}`, { username: user?.username })

      return NextResponse.json({
        success: true,
        account: {
          id: accountId,
          phone,
          firstName: user?.firstName,
          lastName: user?.lastName,
          username: user?.username,
        },
        message: "Muvaffaqiyatli kirildi!",
      })
    } catch (signInError: any) {
      // 2FA tekshirish
      if (signInError.message?.includes("SESSION_PASSWORD_NEEDED")) {
        if (!password) {
          return NextResponse.json(
            {
              error: "2FA_REQUIRED",
              needPassword: true,
              message: "2FA parol kerak",
            },
            { status: 401 }
          )
        }

        // 2FA bilan kirish
        try {
          const passwordResult = await client.invoke(new Api.account.GetPassword())
          const srpResult = await client.invoke(
            new Api.auth.CheckPassword({
              password: await (client as any).computePassword(passwordResult, password),
            })
          )

          const user = (srpResult as any).user
          const session = client.session.save() as unknown as string

          const accountId = `acc_${Date.now()}`
          await execute(
            `INSERT INTO accounts (id, phone, api_id, api_hash, session, first_name, last_name, username, status)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'active')
             ON CONFLICT (phone) DO UPDATE SET
             session = $5, first_name = $6, last_name = $7, username = $8, status = 'active', updated_at = NOW()`,
            [
              accountId,
              phone,
              api_id,
              api_hash,
              session,
              user?.firstName || "",
              user?.lastName || "",
              user?.username || "",
            ]
          )

          await execute("DELETE FROM pending_auth WHERE session_id = $1", [sessionId])
          activeClients.delete(sessionId)
          await client.disconnect()

          await addLog("success", `Akkaunt qo'shildi (2FA): ${phone}`)

          return NextResponse.json({
            success: true,
            account: {
              id: accountId,
              phone,
              firstName: user?.firstName,
              lastName: user?.lastName,
              username: user?.username,
            },
            message: "Muvaffaqiyatli kirildi!",
          })
        } catch (pwdError: any) {
          await addLog("error", "2FA parol xato", { error: pwdError.message })
          return NextResponse.json({ error: "2FA parol noto'g'ri" }, { status: 400 })
        }
      }

      throw signInError
    }
  } catch (error: any) {
    console.error("[v0] Verify code xatosi:", error.message || error)

    let errorMessage = "Kodni tasdiqlashda xatolik"

    if (error.message?.includes("PHONE_CODE_INVALID")) {
      errorMessage = "Kod noto'g'ri"
    } else if (error.message?.includes("PHONE_CODE_EXPIRED")) {
      errorMessage = "Kod muddati o'tgan. Qayta kod oling"
    }

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
