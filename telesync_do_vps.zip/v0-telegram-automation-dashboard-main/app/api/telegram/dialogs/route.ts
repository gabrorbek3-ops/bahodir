import { NextRequest, NextResponse } from "next/server"
import { queryOne, execute, addLog } from "@/lib/db"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const accountId = searchParams.get("accountId")

    if (!accountId) {
      return NextResponse.json({ error: "Akkaunt ID kerak" }, { status: 400 })
    }

    // Akkauntni olish
    const account = await queryOne<any>(
      "SELECT * FROM accounts WHERE id = $1",
      [accountId]
    )

    if (!account) {
      return NextResponse.json({ error: "Akkaunt topilmadi" }, { status: 404 })
    }

    if (!account.session) {
      return NextResponse.json({ error: "Akkaunt sessiyasi yo'q" }, { status: 400 })
    }

    // Telegram client yaratish
    const { TelegramClient, Api } = await import("telegram")
    const { StringSession } = await import("telegram/sessions")

    const stringSession = new StringSession(account.session)
    const client = new TelegramClient(stringSession, account.api_id, account.api_hash, {
      connectionRetries: 5,
    })

    await client.connect()

    // Dialoglarni olish
    const dialogs = await client.getDialogs({ limit: 100 })

    const channels: any[] = []

    for (const dialog of dialogs) {
      if (dialog.isChannel || dialog.isGroup) {
        const entity = dialog.entity as any

        channels.push({
          id: entity.id?.toString(),
          title: dialog.title || "Nomsiz",
          username: entity.username || null,
          participantsCount: entity.participantsCount || 0,
          isChannel: dialog.isChannel,
          isGroup: dialog.isGroup,
          accessHash: entity.accessHash?.toString(),
        })

        // Database ga saqlash
        await execute(
          `INSERT INTO channels (id, telegram_id, title, username, participants_count, is_channel, is_group, access_hash, account_id)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
           ON CONFLICT (id) DO UPDATE SET
           title = $3, username = $4, participants_count = $5`,
          [
            `ch_${entity.id}`,
            entity.id?.toString(),
            dialog.title || "Nomsiz",
            entity.username || null,
            entity.participantsCount || 0,
            dialog.isChannel,
            dialog.isGroup,
            entity.accessHash?.toString(),
            accountId,
          ]
        )
      }
    }

    await client.disconnect()
    await addLog("info", `Kanallar yuklandi: ${channels.length} ta`, { accountId })

    return NextResponse.json({ channels })
  } catch (error: any) {
    console.error("[v0] Dialogs xatosi:", error)
    await addLog("error", "Kanallarni yuklashda xatolik", { error: error.message })
    return NextResponse.json({ error: "Kanallarni yuklashda xatolik" }, { status: 500 })
  }
}
