import { NextRequest, NextResponse } from "next/server"
import { query, queryOne, execute, addLog } from "@/lib/db"

// Barcha akkauntlarni olish
export async function GET() {
  try {
    const accounts = await query(
      `SELECT id, phone, api_id, first_name, last_name, username, status, created_at
       FROM accounts ORDER BY created_at DESC`
    )

    return NextResponse.json({ accounts })
  } catch (error: any) {
    console.error("[v0] Accounts GET xatosi:", error)
    return NextResponse.json({ error: "Akkauntlarni olishda xatolik" }, { status: 500 })
  }
}

// Akkaunt o'chirish
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Akkaunt ID kerak" }, { status: 400 })
    }

    const account = await queryOne("SELECT phone FROM accounts WHERE id = $1", [id])
    
    if (!account) {
      return NextResponse.json({ error: "Akkaunt topilmadi" }, { status: 404 })
    }

    await execute("DELETE FROM accounts WHERE id = $1", [id])
    await addLog("info", `Akkaunt o'chirildi: ${account.phone}`)

    return NextResponse.json({ success: true, message: "Akkaunt o'chirildi" })
  } catch (error: any) {
    console.error("[v0] Accounts DELETE xatosi:", error)
    return NextResponse.json({ error: "Akkauntni o'chirishda xatolik" }, { status: 500 })
  }
}

// Akkaunt statusini yangilash
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, status } = body

    if (!id || !status) {
      return NextResponse.json({ error: "ID va status kerak" }, { status: 400 })
    }

    await execute(
      "UPDATE accounts SET status = $1, updated_at = NOW() WHERE id = $2",
      [status, id]
    )

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("[v0] Accounts PATCH xatosi:", error)
    return NextResponse.json({ error: "Statusni yangilashda xatolik" }, { status: 500 })
  }
}
