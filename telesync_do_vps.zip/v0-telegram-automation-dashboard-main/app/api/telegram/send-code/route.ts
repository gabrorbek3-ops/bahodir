import { NextRequest, NextResponse } from "next/server"
import { query, execute, addLog } from "@/lib/db"
import crypto from "crypto"

// Faol clientlar xotirasi (sessiya davomida kerak)
const activeClients = new Map<string, any>()

// Juda oddiy rate limit (VPS uchun). Server restart bo'lsa ...
const rate = new Map<string, { count: number; resetAt: number }>()

function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now()
  const current = rate.get(key)
  if (!current || current.resetAt < now) {
    rate.set(key, { count: 1, resetAt: now + windowMs })
    return { ok: true, retryAfterMs: 0 }
  }
  if (current.count >= limit) {
    return { ok: false, retryAfterMs: Math.max(0, current.resetAt - now) }
  }
  current.count += 1
  rate.set(key, current)
  return { ok: true, retryAfterMs: 0 }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { phone, apiId, apiHash } = body

    // rate limit: 1 daqiqada 2 ta urinish (ip+phone)
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown"
    const rl = rateLimit(`${ip}:${phone}`, 2, 60_000)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Juda ko'p urinish. ${Math.ceil(rl.retryAfterMs / 1000)} soniya kuting` },
        { status: 429 }
      )
    }

    // Validatsiya
    if (!phone || !apiId || !apiHash) {
      return NextResponse.json(
        { error: "Telefon, API ID va API Hash kerak" },
        { status: 400 }
      )
    }

    // Dinamik import
    const { TelegramClient } = await import("telegram")
    const { StringSession } = await import("telegram/sessions")

    // Yangi client yaratish
    const stringSession = new StringSession("")
    const client = new TelegramClient(stringSession, Number(apiId), apiHash, {
      connectionRetries: 5,
    })

    await client.connect()

    // Kod yuborish
    const result = await client.sendCode(
      {
        apiId: Number(apiId),
        apiHash,
      },
      phone
    )

    // Session ID yaratish
    const sessionId = crypto.randomUUID()

    // Clientni xotirada saqlash
    activeClients.set(sessionId, client)

    // Database ga saqlash
    await execute(
      `INSERT INTO pending_auth (session_id, phone, api_id, api_hash, phone_code_hash)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (session_id) DO UPDATE SET
       phone = $2, api_id = $3, api_hash = $4, phone_code_hash = $5`,
      [sessionId, phone, Number(apiId), apiHash, result.phoneCodeHash]
    )

    await addLog("info", `Kod yuborildi: ${phone}`)

    return NextResponse.json({
      success: true,
      sessionId,
      phoneCodeHash: result.phoneCodeHash,
      message: "Kod yuborildi",
    })
  } catch (error: any) {
    console.error("[v0] Send code xatosi:", error.message || error)

    let errorMessage = "Kod yuborishda xatolik"

    if (error.message?.includes("PHONE_NUMBER_INVALID")) {
      errorMessage = "Telefon raqam noto'g'ri formatda"
    } else if (error.message?.includes("PHONE_NUMBER_BANNED")) {
      errorMessage = "Bu telefon raqam bloklangan"
    } else if (error.message?.includes("API_ID_INVALID")) {
      errorMessage = "API ID noto'g'ri"
    } else if (error.message?.includes("FLOOD_WAIT")) {
      const seconds = error.message.match(/FLOOD_WAIT_(\d+)/)?.[1] || "60"
      errorMessage = `Juda ko'p urinish. ${seconds} soniya kuting`
    }

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}

// Faol clientlarni eksport qilish
export { activeClients }
