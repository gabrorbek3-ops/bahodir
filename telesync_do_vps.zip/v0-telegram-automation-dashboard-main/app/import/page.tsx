import { ImportClient } from "./import-client"

export default function ImportPage() {
  return <ImportClient />
}
