"use client"

import { useState } from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { format } from "date-fns"
import { uz } from "date-fns/locale"
import {
  Plus,
  Search,
  MoreVertical,
  Play,
  Pause,
  X,
  CalendarIcon,
  FileDown,
  CheckCircle,
  Clock,
  AlertTriangle,
  Zap,
  Timer,
} from "lucide-react"

interface ImportTask {
  id: number
  sourceChannel: string
  destChannel: string
  account: string
  status: "running" | "paused" | "completed" | "failed" | "queued"
  progress: number
  importedMessages: number
  totalMessages: number
  startDate: string
  endDate: string
  createdAt: string
  estimatedTime: string
  mode: "fast" | "realtime"
  withMedia: boolean
  preserveDates: boolean
}

const initialTasks: ImportTask[] = [
  {
    id: 1,
    sourceChannel: "@crypto_news_uz",
    destChannel: "@my_crypto_channel",
    account: "Asosiy akkaunt",
    status: "running",
    progress: 67,
    importedMessages: 10050,
    totalMessages: 15000,
    startDate: "2023-01-01",
    endDate: "2023-12-31",
    createdAt: "2024-01-15 10:30",
    estimatedTime: "2 soat 15 daqiqa",
    mode: "fast",
    withMedia: true,
    preserveDates: true,
  },
  {
    id: 2,
    sourceChannel: "@tech_updates",
    destChannel: "@texnologiya_yangiliklari",
    account: "Zaxira akkaunt 1",
    status: "paused",
    progress: 34,
    importedMessages: 2890,
    totalMessages: 8500,
    startDate: "2023-06-01",
    endDate: "2023-12-31",
    createdAt: "2024-01-14 15:45",
    estimatedTime: "4 soat 30 daqiqa",
    mode: "realtime",
    withMedia: true,
    preserveDates: true,
  },
  {
    id: 3,
    sourceChannel: "@world_news",
    destChannel: "@dunyo_yangiliklari",
    account: "Import akkaunt",
    status: "completed",
    progress: 100,
    importedMessages: 25000,
    totalMessages: 25000,
    startDate: "2022-01-01",
    endDate: "2023-12-31",
    createdAt: "2024-01-10 08:00",
    estimatedTime: "Yakunlangan",
    mode: "fast",
    withMedia: true,
    preserveDates: true,
  },
  {
    id: 4,
    sourceChannel: "@dev_group_uz",
    destChannel: "@dasturchilar_arxiv",
    account: "Asosiy akkaunt",
    status: "queued",
    progress: 0,
    importedMessages: 0,
    totalMessages: 67000,
    startDate: "2023-01-01",
    endDate: "2024-01-01",
    createdAt: "2024-01-16 12:00",
    estimatedTime: "Navbatda",
    mode: "fast",
    withMedia: false,
    preserveDates: true,
  },
  {
    id: 5,
    sourceChannel: "@business_tips",
    destChannel: "@biznes_maslahatlari",
    account: "Zaxira akkaunt 1",
    status: "failed",
    progress: 23,
    importedMessages: 1840,
    totalMessages: 8000,
    startDate: "2023-01-01",
    endDate: "2023-06-30",
    createdAt: "2024-01-12 09:15",
    estimatedTime: "Xato",
    mode: "fast",
    withMedia: true,
    preserveDates: true,
  },
]

const statusConfig = {
  running: {
    label: "Ishlayapti",
    icon: Play,
    className: "bg-success/10 text-success border-success/20",
  },
  paused: {
    label: "To'xtatilgan",
    icon: Pause,
    className: "bg-warning/10 text-warning border-warning/20",
  },
  completed: {
    label: "Yakunlangan",
    icon: CheckCircle,
    className: "bg-primary/10 text-primary border-primary/20",
  },
  failed: {
    label: "Xato",
    icon: AlertTriangle,
    className: "bg-destructive/10 text-destructive border-destructive/20",
  },
  queued: {
    label: "Navbatda",
    icon: Clock,
    className: "bg-muted text-muted-foreground border-muted",
  },
}

export function ImportClient() {
  const [tasks, setTasks] = useState<ImportTask[]>(initialTasks)
  const [searchQuery, setSearchQuery] = useState("")
  const [isNewTaskOpen, setIsNewTaskOpen] = useState(false)
  const [dateRange, setDateRange] = useState<{
    from: Date | undefined
    to: Date | undefined
  }>({
    from: undefined,
    to: undefined,
  })
  const [newTask, setNewTask] = useState({
    source: "",
    destination: "",
    account: "",
    mode: "fast" as "fast" | "realtime",
    withMedia: true,
    preserveDates: true,
  })

  const filteredTasks = tasks.filter(
    (task) =>
      task.sourceChannel.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.destChannel.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const runningCount = tasks.filter((t) => t.status === "running").length
  const completedCount = tasks.filter((t) => t.status === "completed").length
  const queuedCount = tasks.filter((t) => t.status === "queued").length
  const totalImported = tasks.reduce((acc, t) => acc + t.importedMessages, 0)

  const handleCreateTask = () => {
    const newId = Math.max(...tasks.map((t) => t.id)) + 1
    const task: ImportTask = {
      id: newId,
      sourceChannel: newTask.source,
      destChannel: newTask.destination,
      account: newTask.account,
      status: "queued",
      progress: 0,
      importedMessages: 0,
      totalMessages: 0,
      startDate: dateRange.from
        ? format(dateRange.from, "yyyy-MM-dd")
        : "2023-01-01",
      endDate: dateRange.to ? format(dateRange.to, "yyyy-MM-dd") : "2024-01-01",
      createdAt: format(new Date(), "yyyy-MM-dd HH:mm"),
      estimatedTime: "Hisoblanmoqda...",
      mode: newTask.mode,
      withMedia: newTask.withMedia,
      preserveDates: newTask.preserveDates,
    }
    setTasks([task, ...tasks])
    setIsNewTaskOpen(false)
    setNewTask({
      source: "",
      destination: "",
      account: "",
      mode: "fast",
      withMedia: true,
      preserveDates: true,
    })
    setDateRange({ from: undefined, to: undefined })
  }

  const handleToggleTask = (id: number) => {
    setTasks(
      tasks.map((t) => {
        if (t.id === id) {
          if (t.status === "running") {
            return { ...t, status: "paused" as const }
          } else if (t.status === "paused" || t.status === "queued") {
            return { ...t, status: "running" as const }
          }
        }
        return t
      })
    )
  }

  const handleCancelTask = (id: number) => {
    setTasks(tasks.filter((t) => t.id !== id))
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="pl-64 transition-all duration-300">
        {/* Header */}
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-background/95 px-6 backdrop-blur">
          <h1 className="text-xl font-semibold text-foreground">
            Import vazifalar
          </h1>
          <Dialog open={isNewTaskOpen} onOpenChange={setIsNewTaskOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                <Plus className="mr-2 h-4 w-4" />
                Yangi import
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Yangi import vazifa yaratish</DialogTitle>
                <DialogDescription>
                  Xabarlarni bir kanaldan boshqasiga import qilish uchun
                  vazifani sozlang.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto">
                <div className="grid gap-2">
                  <Label>Manba kanal</Label>
                  <Input
                    placeholder="@source_channel"
                    value={newTask.source}
                    onChange={(e) =>
                      setNewTask({ ...newTask, source: e.target.value })
                    }
                  />
                </div>
                <div className="grid gap-2">
                  <Label>Maqsad kanal</Label>
                  <Input
                    placeholder="@destination_channel"
                    value={newTask.destination}
                    onChange={(e) =>
                      setNewTask({ ...newTask, destination: e.target.value })
                    }
                  />
                </div>
                <div className="grid gap-2">
                  <Label>Post qiladigan akkaunt</Label>
                  <Select
                    value={newTask.account}
                    onValueChange={(value) =>
                      setNewTask({ ...newTask, account: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Akkauntni tanlang" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Asosiy akkaunt">
                        Asosiy akkaunt
                      </SelectItem>
                      <SelectItem value="Zaxira akkaunt 1">
                        Zaxira akkaunt 1
                      </SelectItem>
                      <SelectItem value="Import akkaunt">
                        Import akkaunt
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label>Sana oralig'i</Label>
                  <div className="flex gap-2">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="flex-1 justify-start text-left font-normal bg-transparent"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {dateRange.from
                            ? format(dateRange.from, "dd.MM.yyyy", {
                                locale: uz,
                              })
                            : "Boshlanish"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={dateRange.from}
                          onSelect={(date) =>
                            setDateRange({ ...dateRange, from: date })
                          }
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="flex-1 justify-start text-left font-normal bg-transparent"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {dateRange.to
                            ? format(dateRange.to, "dd.MM.yyyy", { locale: uz })
                            : "Tugash"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={dateRange.to}
                          onSelect={(date) =>
                            setDateRange({ ...dateRange, to: date })
                          }
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label>Import rejimi</Label>
                  <Select
                    value={newTask.mode}
                    onValueChange={(value: "fast" | "realtime") =>
                      setNewTask({ ...newTask, mode: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fast">
                        <div className="flex items-center">
                          <Zap className="mr-2 h-4 w-4 text-warning" />
                          Tez rejim
                        </div>
                      </SelectItem>
                      <SelectItem value="realtime">
                        <div className="flex items-center">
                          <Timer className="mr-2 h-4 w-4 text-primary" />
                          Real vaqt simulyatsiyasi
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    {newTask.mode === "fast"
                      ? "Xabarlar tezda ketma-ket yuboriladi"
                      : "Xabarlar asl vaqt oralig'ida yuboriladi"}
                  </p>
                </div>

                <div className="space-y-4 rounded-lg border border-border p-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Media fayllarni saqlash</Label>
                      <p className="text-xs text-muted-foreground">
                        Rasm, video, audio va fayllarni import qilish
                      </p>
                    </div>
                    <Switch
                      checked={newTask.withMedia}
                      onCheckedChange={(checked) =>
                        setNewTask({ ...newTask, withMedia: checked })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Asl sanalarni saqlash</Label>
                      <p className="text-xs text-muted-foreground">
                        Xabarlar asl yuborilgan sanada ko'rinadi
                      </p>
                    </div>
                    <Switch
                      checked={newTask.preserveDates}
                      onCheckedChange={(checked) =>
                        setNewTask({ ...newTask, preserveDates: checked })
                      }
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setIsNewTaskOpen(false)}
                >
                  Bekor qilish
                </Button>
                <Button onClick={handleCreateTask}>Boshlash</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </header>

        <div className="p-6 space-y-6">
          {/* Stats */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                    <Play className="h-5 w-5 text-success" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">
                      {runningCount}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Faol vazifalar
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <CheckCircle className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">
                      {completedCount}
                    </p>
                    <p className="text-sm text-muted-foreground">Yakunlangan</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                    <Clock className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">
                      {queuedCount}
                    </p>
                    <p className="text-sm text-muted-foreground">Navbatda</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/10">
                    <FileDown className="h-5 w-5 text-warning" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">
                      {totalImported.toLocaleString()}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Jami import
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tasks Table */}
          <Card className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-foreground">
                Barcha vazifalar
              </CardTitle>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Qidirish..."
                  className="w-64 bg-muted/50 pl-9 border-border"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-border hover:bg-transparent">
                    <TableHead className="text-muted-foreground">
                      Manba - Maqsad
                    </TableHead>
                    <TableHead className="text-muted-foreground">
                      Akkaunt
                    </TableHead>
                    <TableHead className="text-muted-foreground">
                      Sana oralig'i
                    </TableHead>
                    <TableHead className="text-muted-foreground">
                      Holat
                    </TableHead>
                    <TableHead className="text-muted-foreground">
                      Progress
                    </TableHead>
                    <TableHead className="text-muted-foreground">
                      Taxminiy vaqt
                    </TableHead>
                    <TableHead className="text-muted-foreground text-right">
                      Amallar
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTasks.map((task) => {
                    const status = statusConfig[task.status]
                    const StatusIcon = status.icon
                    return (
                      <TableRow
                        key={task.id}
                        className="border-border hover:bg-muted/50"
                      >
                        <TableCell>
                          <div>
                            <p className="font-medium text-foreground">
                              {task.sourceChannel}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              - {task.destChannel}
                            </p>
                          </div>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {task.account}
                        </TableCell>
                        <TableCell className="text-muted-foreground text-sm">
                          <div>
                            <p>{task.startDate}</p>
                            <p>{task.endDate}</p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={status.className}>
                            <StatusIcon className="mr-1 h-3 w-3" />
                            {status.label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            <Progress
                              value={task.progress}
                              className="h-2 w-24"
                            />
                            <p className="text-xs text-muted-foreground">
                              {task.importedMessages.toLocaleString()} /{" "}
                              {task.totalMessages.toLocaleString()}
                            </p>
                          </div>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {task.estimatedTime}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            {(task.status === "running" ||
                              task.status === "paused" ||
                              task.status === "queued") && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => handleToggleTask(task.id)}
                              >
                                {task.status === "running" ? (
                                  <Pause className="h-4 w-4" />
                                ) : (
                                  <Play className="h-4 w-4" />
                                )}
                              </Button>
                            )}
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                >
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  className="text-destructive"
                                  onClick={() => handleCancelTask(task.id)}
                                >
                                  <X className="mr-2 h-4 w-4" />
                                  Bekor qilish
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
