import { NextRequest, NextResponse } from "next/server"

/**
 * Oddiy Basic Auth himoya.
 * VPS (DigitalOcean) uchun tez va ishonchli yo'l.
 *
 * ENV:
 *  - ADMIN_USER
 *  - ADMIN_PASSWORD
 */

const PUBLIC_PATH_PREFIXES = ["/api/health", "/_next", "/favicon.ico"]

function isPublicPath(pathname: string) {
  return PUBLIC_PATH_PREFIXES.some((p) => pathname === p || pathname.startsWith(p))
}

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl

  if (isPublicPath(pathname)) {
    return NextResponse.next()
  }

  const user = process.env.ADMIN_USER
  const pass = process.env.ADMIN_PASSWORD

  // Agar admin kredenshial qo'yilmagan bo'lsa, dev/local uchun bloklamaymiz.
  // Prod'da albatta qo'ying.
  if (!user || !pass) {
    return NextResponse.next()
  }

  const auth = req.headers.get("authorization") || ""
  const [scheme, encoded] = auth.split(" ")

  if (scheme === "Basic" && encoded) {
    try {
      // atob Edge runtime'da mavjud
      const decoded = globalThis.atob(encoded)
      const [u, p] = decoded.split(":")
      if (u === user && p === pass) {
        return NextResponse.next()
      }
    } catch {
      // ignore
    }
  }

  const res = new NextResponse("Auth required", { status: 401 })
  res.headers.set("WWW-Authenticate", 'Basic realm="TeleSync"')
  return res
}

export const config = {
  matcher: ["/:path*"],
}
