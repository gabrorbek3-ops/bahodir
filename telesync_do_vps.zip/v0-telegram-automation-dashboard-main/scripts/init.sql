-- TeleSync Database Schema
-- PostgreSQL

-- Akkauntlar jadvali
CREATE TABLE IF NOT EXISTS accounts (
    id VARCHAR(50) PRIMARY KEY,
    phone VARCHAR(20) NOT NULL UNIQUE,
    api_id INTEGER NOT NULL,
    api_hash VARCHAR(50) NOT NULL,
    session TEXT,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    username VARCHAR(100),
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Kanallar jadvali
CREATE TABLE IF NOT EXISTS channels (
    id VARCHAR(50) PRIMARY KEY,
    telegram_id BIGINT,
    title VARCHAR(255) NOT NULL,
    username VARCHAR(100),
    participants_count INTEGER DEFAULT 0,
    is_channel BOOLEAN DEFAULT true,
    is_group BOOLEAN DEFAULT false,
    access_hash BIGINT,
    account_id VARCHAR(50) REFERENCES accounts(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Kanal ulanishlari (mapping) jadvali
CREATE TABLE IF NOT EXISTS channel_mappings (
    id VARCHAR(50) PRIMARY KEY,
    source_channel_id VARCHAR(50) NOT NULL,
    source_title VARCHAR(255),
    target_channel_id VARCHAR(50) NOT NULL,
    target_title VARCHAR(255),
    account_id VARCHAR(50) REFERENCES accounts(id) ON DELETE CASCADE,
    copy_media BOOLEAN DEFAULT true,
    copy_text BOOLEAN DEFAULT true,
    remove_links BOOLEAN DEFAULT false,
    add_watermark BOOLEAN DEFAULT false,
    watermark_text VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Import vazifalari jadvali
CREATE TABLE IF NOT EXISTS import_tasks (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    source_channel_id VARCHAR(50),
    source_title VARCHAR(255),
    target_channel_id VARCHAR(50),
    target_title VARCHAR(255),
    account_id VARCHAR(50) REFERENCES accounts(id) ON DELETE SET NULL,
    status VARCHAR(20) DEFAULT 'pending',
    progress INTEGER DEFAULT 0,
    total_messages INTEGER DEFAULT 0,
    processed_messages INTEGER DEFAULT 0,
    start_date TIMESTAMP,
    end_date TIMESTAMP,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Filterlar jadvali
CREATE TABLE IF NOT EXISTS filters (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    pattern TEXT,
    replacement TEXT,
    is_active BOOLEAN DEFAULT true,
    priority INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Loglar jadvali
CREATE TABLE IF NOT EXISTS logs (
    id SERIAL PRIMARY KEY,
    level VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    details JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pending auth jadvali (telefon tasdiqlash uchun)
CREATE TABLE IF NOT EXISTS pending_auth (
    session_id VARCHAR(100) PRIMARY KEY,
    phone VARCHAR(20) NOT NULL,
    api_id INTEGER NOT NULL,
    api_hash VARCHAR(50) NOT NULL,
    phone_code_hash VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP + INTERVAL '10 minutes')
);

-- Indekslar
CREATE INDEX IF NOT EXISTS idx_accounts_phone ON accounts(phone);
CREATE INDEX IF NOT EXISTS idx_accounts_status ON accounts(status);
CREATE INDEX IF NOT EXISTS idx_channels_account ON channels(account_id);
CREATE INDEX IF NOT EXISTS idx_mappings_account ON channel_mappings(account_id);
CREATE INDEX IF NOT EXISTS idx_mappings_active ON channel_mappings(is_active);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON import_tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_account ON import_tasks(account_id);
CREATE INDEX IF NOT EXISTS idx_logs_level ON logs(level);
CREATE INDEX IF NOT EXISTS idx_logs_created ON logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_pending_expires ON pending_auth(expires_at);

-- Eski pending auth ni tozalash funksiyasi
CREATE OR REPLACE FUNCTION cleanup_expired_pending_auth()
RETURNS void AS $$
BEGIN
    DELETE FROM pending_auth WHERE expires_at < CURRENT_TIMESTAMP;
END;
$$ LANGUAGE plpgsql;
