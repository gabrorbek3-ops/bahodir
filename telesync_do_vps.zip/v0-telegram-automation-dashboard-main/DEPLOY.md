# TeleSync - Ubuntu VPS ga O'rnatish Qo'llanmasi

## 1-QADAM: VPS ga ulanish

```bash
ssh root@sizning_server_ip
```

---

## 2-QADAM: Tizimni yangilash

```bash
apt update && apt upgrade -y
```

---

## 3-QADAM: Docker o'rnatish

```bash
# Eski versiyalarni o'chirish
apt remove docker docker-engine docker.io containerd runc -y

# Kerakli paketlarni o'rnatish
apt install ca-certificates curl gnupg lsb-release -y

# Docker GPG kalitini qo'shish
mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg

# Docker repositoriyasini qo'shish
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null

# Docker o'rnatish
apt update
apt install docker-ce docker-ce-cli containerd.io docker-compose-plugin -y

# Docker ishga tushganini tekshirish
docker --version
docker compose version
```

---

## 4-QADAM: Loyihani yuklash

### Variant A: GitHub dan (tavsiya etiladi)
```bash
# Git o'rnatish (agar yo'q bo'lsa)
apt install git -y

# Loyihani klonlash
cd /opt
git clone https://github.com/sizning_username/telesync.git
cd telesync
```

### Variant B: Lokal kompyuterdan ko'chirish
```bash
# Lokal kompyuteringizda bu buyruqni bajaring:
scp -r ./telesync root@sizning_server_ip:/opt/

# Serverda:
cd /opt/telesync
```

### Variant C: ZIP fayl orqali
```bash
# v0 dan ZIP yuklab oling, keyin:
apt install unzip -y
cd /opt
unzip telesync.zip -d telesync
cd telesync
```

---

## 5-QADAM: DigitalOcean Database (Managed Postgres) tayyorlash

1) DigitalOcean'da **Managed PostgreSQL** yarating.
2) Connection string'dan `DATABASE_URL` ni oling (ko'pincha `sslmode=require`).
3) Serverdan schema'ni bir marta import qiling:

```bash
# VPS'da (psql kerak bo'ladi)
apt install postgresql-client -y

# Loyihaning ichida:
cd /opt/telesync

# Schema yaratish
psql "$DATABASE_URL" -f scripts/init.sql
```

> Eslatma: DO Managed Postgres'da port ko'pincha `25060` bo'ladi va SSL majburiy.

---

## 6-QADAM: Environment o'zgaruvchilarini sozlash

```bash
# .env faylini yaratish
nano .env
```

Quyidagilarni yozing:
```env
# DigitalOcean Managed Postgres
DATABASE_URL=postgres://USER:PASSWORD@HOST:25060/DB?sslmode=require
DB_SSL=1

# Dashboard + API himoya (Basic Auth)
ADMIN_USER=admin
ADMIN_PASSWORD=strong_password_here
```

Saqlash: `Ctrl+X`, keyin `Y`, keyin `Enter`

---

## 7-QADAM: Ilovani ishga tushirish (DigitalOcean DB bilan)

```bash
# VPS compose (tashqi DB)
docker compose -f docker-compose.vps.yml up -d --build

# Loglarni ko'rish
docker compose -f docker-compose.vps.yml logs -f

# Status tekshirish
docker compose -f docker-compose.vps.yml ps
```

---

## 8-QADAM: Nginx va SSL o'rnatish (domenli)

```bash
# Nginx o'rnatish
apt install nginx -y

# Certbot o'rnatish (SSL uchun)
apt install certbot python3-certbot-nginx -y

# Nginx konfiguratsiyasi
nano /etc/nginx/sites-available/telesync
```

Quyidagini yozing:
```nginx
server {
    listen 80;
    server_name sizning_domen.com www.sizning_domen.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Saytni faollashtirish
ln -s /etc/nginx/sites-available/telesync /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx

# SSL sertifikat olish
certbot --nginx -d sizning_domen.com -d www.sizning_domen.com
```

---

## 8-QADAM: Firewall sozlash

```bash
# UFW yoqish
ufw allow ssh
ufw allow 80
ufw allow 443
ufw enable

# Statusni tekshirish
ufw status
```

---

## FOYDALI BUYRUQLAR

### Ilovani boshqarish
```bash
# To'xtatish
docker compose down

# Qayta ishga tushirish
docker compose restart

# Yangilash (git bilan)
cd /opt/telesync
git pull
docker compose up -d --build

# Loglar
docker compose logs -f telesync

# Konteyner ichiga kirish
docker compose exec telesync sh
```

### Tizim monitoringi
```bash
# Docker konteynerlar holati
docker stats

# Disk holati
df -h

# RAM holati
free -m

# CPU holati
htop
```

### Avtomatik ishga tushirish
```bash
# Docker systemd orqali avtomatik ishga tushadi
systemctl enable docker

# Server qayta ishga tushganda konteynerlar ham ishga tushadi
# (docker-compose.yml da restart: unless-stopped bor)
```

---

## MUAMMOLARNI HAL QILISH

### Port band bo'lsa
```bash
# 3000 portni kim ishlatayotganini ko'rish
lsof -i :3000

# Jarayonni to'xtatish
kill -9 <PID>
```

### Docker permission xatosi
```bash
# Foydalanuvchini docker guruhiga qo'shish
usermod -aG docker $USER
newgrp docker
```

### Xotira yetishmasa
```bash
# Swap yaratish
fallocate -l 2G /swapfile
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile
echo '/swapfile none swap sw 0 0' >> /etc/fstab
```

### Konteyner ishlamasa
```bash
# Batafsil loglar
docker compose logs telesync

# Konteynerlarni tozalash va qaytadan build
docker compose down
docker system prune -a
docker compose up -d --build
```

---

## MINIMAL TALABLAR

- Ubuntu 20.04 yoki 22.04 LTS
- RAM: 1GB (2GB tavsiya)
- Disk: 10GB
- CPU: 1 core (2 core tavsiya)

---

## TEZKOR O'RNATISH (Bir buyruq bilan)

Agar serveringiz yangi bo'lsa, barchasini bir buyruq bilan o'rnatish:

```bash
curl -fsSL https://get.docker.com | sh && \
cd /opt && \
git clone https://github.com/sizning_username/telesync.git && \
cd telesync && \
docker compose up -d --build
```

Shundan so'ng http://sizning_server_ip:3000 manzilida ilova ishlaydi.
