import postgres from "postgres"

/**
 * Postgres ulanishi (DigitalOcean Managed Postgres bilan mos).
 * DATABASE_URL odatda shunaqa bo'ladi:
 *   postgres://USER:PASSWORD@HOST:25060/DB?sslmode=require
 */

const DATABASE_URL = process.env.DATABASE_URL

if (!DATABASE_URL) {
  throw new Error("DATABASE_URL env yo'q. .env yoki Docker env orqali bering")
}

// DO Managed Postgres ko'pincha SSL talab qiladi.
// postgres (porsager) kutubxonasi uchun:
//  - ssl: 'require' -> TLS ishlatadi
//  - ssl: false -> local postgres
const shouldUseSSL =
  /sslmode=require/i.test(DATABASE_URL) ||
  process.env.DB_SSL === "1" ||
  process.env.DB_SSL === "true"

export const sql = postgres(DATABASE_URL, {
  ssl: shouldUseSSL ? "require" : false,
  // serverda ko'p query bo'lsa yordam beradi
  max: Number(process.env.DB_POOL_MAX || 10),
  idle_timeout: Number(process.env.DB_IDLE_TIMEOUT || 20),
  connect_timeout: Number(process.env.DB_CONNECT_TIMEOUT || 30),
})

export async function query<T = any>(text: string, params?: any[]): Promise<T[]> {
  try {
    const result = await sql.unsafe(text, params || [])
    return result as T[]
  } catch (error) {
    console.error("[DB] Query xatosi:", error)
    throw error
  }
}

export async function queryOne<T = any>(text: string, params?: any[]): Promise<T | null> {
  const rows = await query<T>(text, params)
  return rows[0] || null
}

export async function execute(text: string, params?: any[]): Promise<number> {
  try {
    const result = await sql.unsafe(text, params || [])
    return Array.isArray(result) ? result.length : 0
  } catch (error) {
    console.error("[DB] Execute xatosi:", error)
    throw error
  }
}

export async function addLog(
  level: "info" | "warning" | "error" | "success",
  message: string,
  details?: any
) {
  try {
    await sql.unsafe("INSERT INTO logs (level, message, details) VALUES ($1, $2, $3)", [
      level,
      message,
      details ? JSON.stringify(details) : null,
    ])
  } catch (error) {
    console.error("[DB] Log xatosi:", error)
  }
}
