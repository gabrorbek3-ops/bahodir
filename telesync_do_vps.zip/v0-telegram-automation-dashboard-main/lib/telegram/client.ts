// Telegram client utilities
// Types are imported from store.ts to avoid circular dependencies

import type { AccountData, ChannelData } from "./store"

export type { AccountData, ChannelData }

// Client yaratish - dinamik import bilan
export async function createTelegramClient(
  apiId: number,
  apiHash: string,
  session: string = ""
) {
  const { TelegramClient } = await import("telegram")
  const { StringSession } = await import("telegram/sessions")
  
  const stringSession = new StringSession(session)
  
  const client = new TelegramClient(stringSession, apiId, apiHash, {
    connectionRetries: 5,
  })
  
  return client
}

// Dialoglar (kanallar, guruhlar) ro'yxatini olish
export async function getDialogs(
  apiId: number,
  apiHash: string,
  session: string
): Promise<ChannelData[]> {
  const { Api } = await import("telegram")
  const client = await createTelegramClient(apiId, apiHash, session)
  await client.connect()
  
  const dialogs = await client.getDialogs({
    limit: 500,
  })
  
  const channels: ChannelData[] = []
  
  for (const dialog of dialogs) {
    const entity = dialog.entity
    
    if (entity instanceof Api.Channel || entity instanceof Api.Chat) {
      const isChannel = entity instanceof Api.Channel && entity.broadcast
      const isGroup = entity instanceof Api.Channel ? !entity.broadcast : true
      
      channels.push({
        id: entity.id.toString(),
        title: dialog.title || "Nomsiz",
        username: entity instanceof Api.Channel ? entity.username : undefined,
        participantsCount: entity instanceof Api.Channel ? entity.participantsCount : undefined,
        isChannel,
        isGroup,
        accessHash: entity instanceof Api.Channel ? entity.accessHash?.toString() : undefined,
      })
    }
  }
  
  await client.disconnect()
  
  return channels
}

// Xabar yuborish
export async function sendMessage(
  apiId: number,
  apiHash: string,
  session: string,
  chatId: string,
  message: string
): Promise<void> {
  const client = await createTelegramClient(apiId, apiHash, session)
  await client.connect()
  
  await client.sendMessage(chatId, { message })
  
  await client.disconnect()
}

// Xabarlarni ko'chirish
export async function forwardMessages(
  apiId: number,
  apiHash: string,
  session: string,
  fromChat: string,
  toChat: string,
  messageIds: number[]
): Promise<void> {
  const client = await createTelegramClient(apiId, apiHash, session)
  await client.connect()
  
  await client.forwardMessages(toChat, {
    messages: messageIds,
    fromPeer: fromChat,
  })
  
  await client.disconnect()
}

// Kanal xabarlarini olish
export async function getChannelMessages(
  apiId: number,
  apiHash: string,
  session: string,
  channelId: string,
  limit: number = 100,
  offsetId: number = 0
) {
  const client = await createTelegramClient(apiId, apiHash, session)
  await client.connect()
  
  const messages = await client.getMessages(channelId, {
    limit,
    offsetId,
  })
  
  await client.disconnect()
  
  return messages
}

// Akkaunt ma'lumotlarini olish
export async function getMe(
  apiId: number,
  apiHash: string,
  session: string
) {
  const client = await createTelegramClient(apiId, apiHash, session)
  await client.connect()
  
  const me = await client.getMe()
  
  await client.disconnect()
  
  return me
}
