// Oddiy in-memory store (production uchun database kerak)
// Bu yerda localStorage o'rniga server-side store ishlatamiz

// Type definitions (circular import oldini olish uchun)
export interface AccountData {
  id: string
  phone: string
  apiId: number
  apiHash: string
  session: string
  firstName?: string
  lastName?: string
  username?: string
  status: "active" | "inactive" | "banned"
  createdAt: string
}

export interface ChannelData {
  id: string
  title: string
  username?: string
  participantsCount?: number
  isChannel: boolean
  isGroup: boolean
  accessHash?: string
}

// Active clients storage (TelegramClient instancelari)
// biome-ignore lint: any kerak chunki TelegramClient turini import qilib bo'lmaydi
const activeClients = new Map<string, any>()

// Vaqtinchalik xotira (server restart bo'lganda yo'qoladi)
// Production uchun Redis yoki Database ishlatish kerak
const memoryStore: {
  accounts: Map<string, AccountData>
  channels: Map<string, ChannelData>
  mappings: Map<string, { sourceId: string; targetId: string; accountId: string }>
  pendingAuth: Map<string, { 
    phone: string
    apiId: number
    apiHash: string
    phoneCodeHash: string
    expiresAt: number 
  }>
} = {
  accounts: new Map(),
  channels: new Map(),
  mappings: new Map(),
  pendingAuth: new Map(),
}

// Akkauntlar
export function getAccounts(): AccountData[] {
  return Array.from(memoryStore.accounts.values())
}

export function getAccount(id: string): AccountData | undefined {
  return memoryStore.accounts.get(id)
}

export function saveAccount(account: AccountData): void {
  memoryStore.accounts.set(account.id, account)
}

export function deleteAccount(id: string): boolean {
  return memoryStore.accounts.delete(id)
}

export function updateAccountStatus(id: string, status: AccountData["status"]): void {
  const account = memoryStore.accounts.get(id)
  if (account) {
    account.status = status
    memoryStore.accounts.set(id, account)
  }
}

// Kanallar
export function getChannels(): ChannelData[] {
  return Array.from(memoryStore.channels.values())
}

export function saveChannel(channel: ChannelData): void {
  memoryStore.channels.set(channel.id, channel)
}

export function saveChannels(channels: ChannelData[]): void {
  for (const channel of channels) {
    memoryStore.channels.set(channel.id, channel)
  }
}

// Pending Auth (kod kutish)
export function savePendingAuth(
  sessionId: string,
  data: {
    phone: string
    apiId: number
    apiHash: string
    phoneCodeHash: string
  }
): void {
  memoryStore.pendingAuth.set(sessionId, {
    ...data,
    expiresAt: Date.now() + 5 * 60 * 1000, // 5 daqiqa
  })
}

export function getPendingAuth(sessionId: string) {
  const data = memoryStore.pendingAuth.get(sessionId)
  if (!data) return undefined
  
  // Muddati o'tgan bo'lsa o'chiramiz
  if (data.expiresAt < Date.now()) {
    memoryStore.pendingAuth.delete(sessionId)
    return undefined
  }
  
  return data
}

export function deletePendingAuth(sessionId: string): void {
  memoryStore.pendingAuth.delete(sessionId)
}

// Kanal mappinglar
export function getMappings() {
  return Array.from(memoryStore.mappings.values())
}

export function saveMapping(
  id: string,
  data: { sourceId: string; targetId: string; accountId: string }
): void {
  memoryStore.mappings.set(id, data)
}

export function deleteMapping(id: string): boolean {
  return memoryStore.mappings.delete(id)
}

// Active Telegram Clients
// biome-ignore lint: any kerak
export function saveActiveClient(sessionId: string, client: any): void {
  activeClients.set(sessionId, client)
  
  // 10 daqiqadan keyin avtomatik o'chirish
  setTimeout(() => {
    const c = activeClients.get(sessionId)
    if (c) {
      try {
        c.disconnect()
      } catch {}
      activeClients.delete(sessionId)
    }
  }, 10 * 60 * 1000)
}

// biome-ignore lint: any kerak
export function getActiveClient(sessionId: string): any | undefined {
  return activeClients.get(sessionId)
}

export function deleteActiveClient(sessionId: string): void {
  const client = activeClients.get(sessionId)
  if (client) {
    try {
      client.disconnect()
    } catch {}
    activeClients.delete(sessionId)
  }
}
