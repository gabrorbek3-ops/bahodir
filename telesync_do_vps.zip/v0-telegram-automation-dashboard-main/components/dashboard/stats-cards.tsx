"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Users, Radio, Link2, FileDown, Clock, AlertTriangle } from "lucide-react"
import useSWR from "swr"

const fetcher = (url: string) => fetch(url).then((res) => res.json())

export function StatsCards() {
  const { data, error } = useSWR("/api/telegram/stats", fetcher, {
    refreshInterval: 10000,
  })

  const stats = [
    {
      title: "Faol akkauntlar",
      value: data?.stats?.accounts || 0,
      icon: Users,
    },
    {
      title: "Kanallar",
      value: data?.stats?.channels || 0,
      icon: Radio,
    },
    {
      title: "Bog'lanishlar",
      value: data?.stats?.mappings || 0,
      icon: Link2,
    },
    {
      title: "Bugungi xabarlar",
      value: data?.stats?.todayMessages || 0,
      icon: FileDown,
    },
    {
      title: "Faol vazifalar",
      value: data?.stats?.activeTasks || 0,
      icon: Clock,
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
      {stats.map((stat) => (
        <Card key={stat.title} className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                <stat.icon className="h-5 w-5 text-muted-foreground" />
              </div>
            </div>
            <div className="mt-3">
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.title}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
