"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Pause, Play, X, MoreVertical } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const activeTasks = [
  {
    id: 1,
    sourceName: "@crypto_news_uz",
    destName: "@my_crypto_channel",
    progress: 67,
    totalMessages: 15000,
    importedMessages: 10050,
    status: "running" as const,
    account: "account_1",
    startDate: "2024-01-15",
    estimatedTime: "2 soat 15 daqiqa",
  },
  {
    id: 2,
    sourceName: "@tech_updates",
    destName: "@texnologiya_yangiliklari",
    progress: 34,
    totalMessages: 8500,
    importedMessages: 2890,
    status: "paused" as const,
    account: "account_2",
    startDate: "2024-01-14",
    estimatedTime: "4 soat 30 daqiqa",
  },
  {
    id: 3,
    sourceName: "@world_news",
    destName: "@dunyo_yangiliklari",
    progress: 89,
    totalMessages: 25000,
    importedMessages: 22250,
    status: "running" as const,
    account: "account_3",
    startDate: "2024-01-13",
    estimatedTime: "45 daqiqa",
  },
]

export function ActiveTasks() {
  return (
    <Card className="bg-card border-border">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-foreground">Faol vazifalar</CardTitle>
        <Button variant="outline" size="sm">
          Barchasini ko'rish
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {activeTasks.map((task) => (
          <div
            key={task.id}
            className="rounded-lg border border-border bg-muted/30 p-4"
          >
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-foreground">
                    {task.sourceName}
                  </span>
                  <span className="text-muted-foreground">→</span>
                  <span className="font-medium text-foreground">
                    {task.destName}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <span>Akkaunt: {task.account}</span>
                  <span>•</span>
                  <span>Boshlanish: {task.startDate}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge
                  variant={task.status === "running" ? "default" : "secondary"}
                  className={
                    task.status === "running"
                      ? "bg-success text-success-foreground"
                      : "bg-warning text-warning-foreground"
                  }
                >
                  {task.status === "running" ? "Ishlayapti" : "To'xtatilgan"}
                </Badge>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      {task.status === "running" ? (
                        <>
                          <Pause className="mr-2 h-4 w-4" />
                          To'xtatish
                        </>
                      ) : (
                        <>
                          <Play className="mr-2 h-4 w-4" />
                          Davom ettirish
                        </>
                      )}
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-destructive">
                      <X className="mr-2 h-4 w-4" />
                      Bekor qilish
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>

            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">
                  {task.importedMessages.toLocaleString()} /{" "}
                  {task.totalMessages.toLocaleString()} xabar
                </span>
                <span className="font-medium text-foreground">
                  {task.progress}%
                </span>
              </div>
              <Progress value={task.progress} className="h-2" />
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>Taxminiy vaqt: {task.estimatedTime}</span>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
