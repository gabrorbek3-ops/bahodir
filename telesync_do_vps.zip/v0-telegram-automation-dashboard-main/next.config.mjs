/** @type {import('next').NextConfig} */
const nextConfig = {
  // typescript build error'larni yashirmang. Prod'da runtime xatolar kamayadi.
  images: {
    unoptimized: true,
  },
  // Docker uchun standalone output
  output: 'standalone',
}

export default nextConfig
